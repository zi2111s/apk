@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-apk.ps1"
if errorlevel 1 (
  echo.
  echo Build did not finish. Please check the error above.
  pause
  exit /b 1
)
echo.
echo The APK is ScreenPulse-debug.apk in this folder.
pause
