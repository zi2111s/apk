import com.screenpulse.app.UsageEngine
import com.screenpulse.app.UsageSourcePolicy
import com.screenpulse.app.UsageEngine.Event
import com.screenpulse.app.UsageEngine.Kind

fun main() {
    val t = 1_700_000_000_000L
    fun checkDuration(result: UsageEngine.Result, expected: Long) {
        check(result.totalMillis == expected) { "Expected $expected got ${result.totalMillis}; ${result.appMillis}" }
        check(result.appMillis.values.sum() == result.hourlyMillis.sum())
    }
    val base = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 10_000, "qq", Kind.PAUSE, "Main"),
        Event(t + 10_000, "red", Kind.RESUME, "Main"),
        Event(t + 25_000, "", Kind.SCREEN_OFF),
        Event(t + 35_000, "", Kind.SCREEN_ON),
        Event(t + 45_000, "red", Kind.PAUSE, "Main")
    ), t, t + 50_000)
    checkDuration(base, 35_000L)

    val switched = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "A"),
        Event(t + 30_000, "red", Kind.RESUME, "B"),
        Event(t + 70_000, "red", Kind.PAUSE, "B"),
        Event(t + 70_000, "game", Kind.RESUME, "C")
    ), t, t + 90_000)
    checkDuration(switched, 90_000)

    // A common OEM callback order: new activity in same package RESUMEs
    // before the old Activity PAUSEs. The old reducer dropped that entire session.
    val internalNavigation = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "ActivityA"),
        Event(t + 10_000, "qq", Kind.RESUME, "ActivityB"),
        Event(t + 11_000, "qq", Kind.PAUSE, "ActivityA"),
        Event(t + 15_000, "qq", Kind.PAUSE, "ActivityB")
    ), t, t + 20_000)
    checkDuration(internalNavigation, 15_000)

    val spuriousPause = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "ActivityA"),
        Event(t + 4000, "qq", Kind.PAUSE, "UnknownActivity"),
        Event(t + 10000, "qq", Kind.PAUSE, "ActivityA")
    ), t, t + 12000)
    checkDuration(spuriousPause, 10000)

    // Some OEMs send KEYGUARD_SHOWN but not KEYGUARD_HIDDEN.
    // A subsequent ACTIVITY_RESUMED must reopen recording.
    val staleLock = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 1000, "", Kind.LOCK),
        Event(t + 5000, "", Kind.SCREEN_ON),
        Event(t + 8000, "qq", Kind.RESUME, "Main")
    ), t, t + 20000)
    checkDuration(staleLock, 13000)

    val clipped = UsageEngine.reduce(listOf(
        Event(t - 10000, "music", Kind.RESUME, "Main")), t, t + 2000)
    checkDuration(clipped, 2000)

    val priorActivityPause = UsageEngine.reduce(listOf(
        Event(t, "A", Kind.RESUME, "Main"),
        Event(t + 1000, "B", Kind.RESUME, "Main"),
        Event(t + 1500, "A", Kind.PAUSE, "Main"),
        Event(t + 5000, "B", Kind.PAUSE, "Main")
    ), t, t + 7000)
    checkDuration(priorActivityPause, 5000)
    // The exact error seen on the phone: event stream under-reports by >1 h,
    // but Android daily aggregate has the missing foreground use.
    check(UsageSourcePolicy.preferDaily(3*3600_000L + 41*60_000L,
        5*3600_000L + 32*60_000L, 18*3600_000L))
    check(!UsageSourcePolicy.preferDaily(5*3600_000L,
        2*3600_000L, 18*3600_000L))
    check(!UsageSourcePolicy.preferDaily(2*3600_000L,
        30*3600_000L, 18*3600_000L))
    check(UsageSourcePolicy.reliableAverage(listOf(
        true to 3_600_000L, true to 4_800_000L, false to 0L,
        false to 0L, false to 0L, false to 0L, false to 0L
    )) == null)
    check(UsageSourcePolicy.reliableAverage(listOf(
        true to 3_600_000L, true to 3_600_000L, true to 3_600_000L,
        true to 3_600_000L, true to 3_600_000L,
        false to 0L, false to 0L
    )) == 3_600_000L)
    println("UsageEngine + UsageSourcePolicy: 12 tests passed")
}
