import com.screenpulse.app.UsageEngine
import com.screenpulse.app.UsageEngine.Event
import com.screenpulse.app.UsageEngine.Kind

fun main() {
    val t = 1_700_000_000_000L
    val ev = listOf(
        Event(t, "qq", Kind.RESUME),
        Event(t + 10_000, "qq", Kind.PAUSE),
        Event(t + 10_000, "red", Kind.RESUME),
        Event(t + 25_000, "", Kind.SCREEN_OFF),
        Event(t + 35_000, "", Kind.SCREEN_ON),
        Event(t + 45_000, "red", Kind.PAUSE)
    )
    val r = UsageEngine.reduce(ev, t, t + 50_000)
    check(r.appMillis["qq"] == 10_000L) { r.toString() }
    check(r.appMillis["red"] == 25_000L) { r.toString() }
    check(r.totalMillis == 35_000L)
    check(r.currentApp == null)
    check(r.hourlyMillis.sum() == 35_000L)

    // Midnight-style interval must clip an ongoing session, not count preceding time.
    val clipped = UsageEngine.reduce(
        listOf(Event(t - 20_000, "music", Kind.RESUME)), t, t + 2_000
    )
    check(clipped.totalMillis == 2_000L)
    check(clipped.currentApp == "music")

    // Switching Android activities inside the same package must not reset usage.
    val samePackage = UsageEngine.reduce(
        listOf(Event(t, "reader", Kind.RESUME), Event(t + 1000, "reader", Kind.RESUME)),
        t, t + 5_000
    )
    check(samePackage.appMillis["reader"] == 5_000L)
    check(samePackage.openings == 1)

    // Do not count locked-screen time even when an app technically remains resumed.
    val locked = UsageEngine.reduce(
        listOf(Event(t, "qq", Kind.RESUME), Event(t + 1000, "", Kind.LOCK),
               Event(t + 5000, "", Kind.UNLOCK)), t, t + 6000
    )
    check(locked.totalMillis == 2000L)
    // Application totals and hourly bins must be consistent with one another.
    // The former UI mixed screen events with app events and could show a
    // headline smaller than the sum of listed app durations.
    val switch = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME),
        Event(t + 30_000, "red", Kind.RESUME),
        Event(t + 70_000, "red", Kind.PAUSE),
        Event(t + 70_000, "game", Kind.RESUME)
    ), t, t + 90_000)
    check(switch.totalMillis == 90_000L)
    check(switch.appMillis.values.sum() == switch.hourlyMillis.sum())
    check(switch.appMillis["qq"] == 30_000L)
    check(switch.appMillis["red"] == 40_000L)
    check(switch.appMillis["game"] == 20_000L)
    println("UsageEngine: 5 tests passed")
}
