import com.screenpulse.app.UsageEngine
import com.screenpulse.app.UsageSourcePolicy
import com.screenpulse.app.UsageEngine.Event
import com.screenpulse.app.UsageEngine.Kind

fun main() {
    val t = 1_700_000_000_000L
    fun checkDuration(result: UsageEngine.Result, expected: Long) {
        check(result.totalMillis == expected) { "Expected $expected got ${result.totalMillis}; ${result.appMillis}" }
        check(result.appMillis.values.sum() == result.hourlyMillis.sum())
    }
    val base = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 10_000, "qq", Kind.PAUSE, "Main"),
        Event(t + 10_000, "red", Kind.RESUME, "Main"),
        Event(t + 25_000, "", Kind.SCREEN_OFF),
        Event(t + 35_000, "", Kind.SCREEN_ON),
        Event(t + 45_000, "red", Kind.PAUSE, "Main")
    ), t, t + 50_000)
    checkDuration(base, 35_000L)

    val switched = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "A"),
        Event(t + 30_000, "red", Kind.RESUME, "B"),
        Event(t + 70_000, "red", Kind.PAUSE, "B"),
        Event(t + 70_000, "game", Kind.RESUME, "C")
    ), t, t + 90_000)
    checkDuration(switched, 90_000)

    // A common OEM callback order: new activity in same package RESUMEs
    // before the old Activity PAUSEs. The old reducer dropped that entire session.
    val internalNavigation = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "ActivityA"),
        Event(t + 10_000, "qq", Kind.RESUME, "ActivityB"),
        Event(t + 11_000, "qq", Kind.PAUSE, "ActivityA"),
        Event(t + 15_000, "qq", Kind.PAUSE, "ActivityB")
    ), t, t + 20_000)
    checkDuration(internalNavigation, 15_000)

    val spuriousPause = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "ActivityA"),
        Event(t + 4000, "qq", Kind.PAUSE, "UnknownActivity"),
        Event(t + 10000, "qq", Kind.PAUSE, "ActivityA")
    ), t, t + 12000)
    checkDuration(spuriousPause, 10000)

    // Some OEMs send KEYGUARD_SHOWN but not KEYGUARD_HIDDEN.
    // A subsequent ACTIVITY_RESUMED must reopen recording.
    val staleLock = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 1000, "", Kind.LOCK),
        Event(t + 5000, "", Kind.SCREEN_ON),
        Event(t + 8000, "qq", Kind.RESUME, "Main")
    ), t, t + 20000)
    checkDuration(staleLock, 13000)

    val clipped = UsageEngine.reduce(listOf(
        Event(t - 10000, "music", Kind.RESUME, "Main")), t, t + 2000)
    checkDuration(clipped, 2000)

    val priorActivityPause = UsageEngine.reduce(listOf(
        Event(t, "A", Kind.RESUME, "Main"),
        Event(t + 1000, "B", Kind.RESUME, "Main"),
        Event(t + 1500, "A", Kind.PAUSE, "Main"),
        Event(t + 5000, "B", Kind.PAUSE, "Main")
    ), t, t + 7000)
    checkDuration(priorActivityPause, 5000)
    // OEM daily totals are NEVER automatically substituted for observed foreground events.
    // The 18:14 device observation had daily sum 6:23 vs official 5:47;
    // choosing the larger source was proven to be incorrect.
    val foregroundOnly = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 70_000L, "qq", Kind.PAUSE, "Main"),
        Event(t + 70_000L, "red", Kind.RESUME, "Main"),
        Event(t + 130_000L, "red", Kind.PAUSE, "Main")
    ), t, t + 200_000L)
    checkDuration(foregroundOnly, 130_000L)
    check(foregroundOnly.appMillis["qq"] == 70_000L)
    check(foregroundOnly.appMillis["red"] == 60_000L)

    // SCREEN_INTERACTIVE is distinct from an app's foreground time:
    // a 20s gap in the launcher remains screen-on but not app foreground.
    val screenSessions = UsageEngine.reduce(listOf(
        Event(t, "", Kind.SCREEN_ON),
        Event(t + 10_000L, "qq", Kind.RESUME, "Main"),
        Event(t + 20_000L, "qq", Kind.PAUSE, "Main"),
        Event(t + 40_000L, "", Kind.SCREEN_OFF)
    ), t, t + 60_000L)
    checkDuration(screenSessions, 10_000L)
    check(screenSessions.screenMillis == 40_000L)
    check(screenSessions.hasScreenEvents)

    // When the device doesn't emit SCREEN_ON until later, a user-visible
    // RESUME can seed a lower-bound interval, but the data is still distinct.
    val inferredFirstScreen = UsageEngine.reduce(listOf(
        Event(t, "qq", Kind.RESUME, "Main"),
        Event(t + 15_000L, "", Kind.SCREEN_OFF)
    ), t, t + 25_000L)
    checkDuration(inferredFirstScreen, 15_000L)
    check(inferredFirstScreen.screenMillis == 15_000L)

    check(UsageSourcePolicy.reliableAverage(listOf(
        true to 3_600_000L, true to 4_800_000L, false to 0L,
        false to 0L, false to 0L, false to 0L, false to 0L
    )) == null)
    check(UsageSourcePolicy.reliableAverage(listOf(
        true to 3_600_000L, true to 3_600_000L, true to 3_600_000L,
        true to 3_600_000L, true to 3_600_000L,
        false to 0L, false to 0L
    )) == 3_600_000L)
    println("UsageEngine + UsageSourcePolicy: regression scenarios passed")
}
