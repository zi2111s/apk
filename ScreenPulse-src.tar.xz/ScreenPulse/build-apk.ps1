# Run on Windows after installing Android Studio and the Android 35 SDK.
# Downloads Gradle from the official Gradle distribution service if needed.
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
Write-Host "[1/4] Checking Java and Android SDK..."

if (-not $env:JAVA_HOME) {
    $candidates = @(
        "${env:ProgramFiles}\Android\Android Studio\jbr",
        "${env:ProgramFiles}\Eclipse Adoptium\jdk-21",
        "${env:ProgramFiles}\Java\jdk-21"
    )
    foreach ($candidate in $candidates) {
        if (Test-Path (Join-Path $candidate 'bin\java.exe')) {
            $env:JAVA_HOME = $candidate
            break
        }
    }
}
if ($env:JAVA_HOME) { $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH }
if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    throw 'Java was not found. Install Android Studio (it includes a JBR runtime).'
}

if (-not $env:ANDROID_HOME) { $env:ANDROID_HOME = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not $env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT = $env:ANDROID_HOME }
if (-not (Test-Path (Join-Path $env:ANDROID_HOME 'platforms\android-35\android.jar'))) {
    throw 'Android API 35 SDK missing. In Android Studio open Tools > SDK Manager > SDK Platforms and install Android 15 (API 35).'
}

Write-Host "[2/4] Ensuring Gradle 8.11.1 is available..."
$cache = Join-Path $env:LOCALAPPDATA 'ScreenPulseBuildTools'
$gradle = Join-Path $cache 'gradle-8.11.1\bin\gradle.bat'
if (-not (Test-Path $gradle)) {
    New-Item -ItemType Directory -Force -Path $cache | Out-Null
    $zip = Join-Path $cache 'gradle-8.11.1-bin.zip'
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $zip
    Expand-Archive -LiteralPath $zip -DestinationPath $cache -Force
    Remove-Item $zip -Force
}

Write-Host "[3/4] Compiling app (Gradle will fetch the Android plugins)..."
Push-Location $project
try {
    & $gradle --no-daemon :app:assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed (exit $LASTEXITCODE)." }
    $apk = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $apk)) { throw 'Build succeeded but the APK was not found.' }
    Copy-Item $apk (Join-Path $project 'ScreenPulse-debug.apk') -Force
    Write-Host "[4/4] Done!" -ForegroundColor Green
    Write-Host (Join-Path $project 'ScreenPulse-debug.apk') -ForegroundColor Cyan
} finally {
    Pop-Location
}
