# 屏幕脉搏 ScreenPulse — Android 屏幕使用时长监控

这是一个**可直接用 Android Studio 打开、编译、安装的原生 Android 工程**，不是网页或 UI 示意图。全部实现采用 Kotlin + Android 系统组件，无广告、无账号、无联网权限、无第三方 SDK。

## 已完成的功能

- **今日实时统计**：查询 Android `UsageStatsManager` 使用事件，按事件还原前台应用使用区间，汇总今日时长。
- **应用排行**：应用名称、图标、使用时长和横向占比；点击应用可独立设置每日分钟数限额。
- **24 小时柱状图**：基于当前可查询的系统事件绘制真实小时汇总；不虚构缺失小时数据。
- **7 天 / 30 天趋势**：优先使用近期事件；旧日期采用 Android 系统的每日聚合统计。
- **后台实时监控**：用户明确开启后以约 30 秒间隔刷新持续通知；通知可一键停止。
- **可选悬浮计时**：授权“显示在其他应用上层”后，显示可拖动的 `HH:MM` 计时气泡。
- **提醒**：每日总量、单个应用每日限额、连续使用某应用的提醒；不强行锁定其他应用。
- **CSV 导出**：通过系统保存文件对话框，导出近 7 天的应用时长，可用 Excel 打开。

## 在 Windows 上构建 APK（推荐）

1. 安装 **Android Studio**（自带 Java 运行时）。首次打开 Android Studio 完成 SDK 安装。
2. 打开 Android Studio 的 **SDK Manager**，确保安装 **Android 15 (API 35)** 的 SDK Platform。
3. 解压本工程，在工程根目录双击 `build-apk.bat`。首次构建须联网，脚本从 Gradle 官方站点下载 Gradle 8.11.1，并通过 Google Maven、Maven Central 下载构建插件。
4. 构建成功后，工程根目录生成 **`ScreenPulse-debug.apk`**；将它传到手机安装即可。也可以用 Android Studio 打开本工程、使用 IDE 的 Gradle 同步和 **Run** 功能编译安装。

> 注意：`build-apk.bat` 不包含 Android SDK 或 Gradle 本体，需要电脑有 Android Studio 和正常访问官方依赖仓库的网络。若电脑已经配置了其他 JDK，也可以设置 `JAVA_HOME`。如果官方 Gradle 下载/谷歌 Maven 被网络阻断，请配置代理后重试。

## 首次在手机上使用

1. 打开 **屏幕脉搏**，点击 **打开使用情况访问设置**。
2. 在系统列表中找到 **屏幕脉搏**，启用 **允许查看使用情况 / 使用情况访问权限**，然后返回应用。
3. “今日”页面将自动显示今日使用时长、小时图及应用排行榜（取决于系统可提供的历史事件）。
4. 进入 **设置**，开启 **状态栏实时监控**。Android 13+ 请允许通知，以便正常显示持续通知和限额提醒。
5. 可选：打开 **浮动计时气泡**，在系统设置中授予 **显示在其他应用上层** 权限。也可以配置使用上限。

### vivo 等厂商系统

系统可能将持续后台服务限制或停止。若希望长时间保持实时通知，可以在系统的应用电池管理中允许此应用后台运行；具体菜单因系统版本而异。应用不主动请求绕过电池优化权限。

## 统计口径与限制

- **前台使用时长 ≠ 物理屏幕亮屏时间。** 这是按 Android 提供的应用前台事件计算的使用时长；系统“健康使用设备”的统计口径可能不同。
- Android 只保存有限天数的原始使用事件，因此较旧日期会回退到系统每日聚合数据；这些日期不会生成虚假的小时分布。
- 某些 OEM 省电策略会终止前台服务；开机后需要由用户重新打开应用启动监控。并不承诺始终每秒更新或 100% 与系统统计相同。
- Android 11+ 的应用可见性限制可能导致少数应用只显示包名，但其时长仍可统计。
- 悬浮窗必须单独取得系统授权。后台监控不会截图、读取聊天内容、收集密码、使用无障碍权限或读取通知内容。
- **数据只留在本机。** 工程没有 `INTERNET` 权限，没有远端服务器。
- 这个版本提供的是**使用限额提醒**，而不是通过系统特殊管理权限强制锁定应用。

## 目录结构

```text
ScreenPulse/
├── app/src/main/AndroidManifest.xml
├── app/src/main/java/com/screenpulse/app/
│   ├── MainActivity.kt       # 界面、今日/趋势/设置、CSV 导出
│   ├── UsageRepository.kt   # 安卓系统数据源、历史回退
│   ├── UsageEngine.kt       # 事件计时算法（可在 JVM 单元运行）
│   └── MonitorService.kt    # 前台服务、限额通知、可选悬浮窗
├── app/src/main/res/        # 主题和图标
├── tests/UsageEngineTest.kt # 算法场景验证
├── build-apk.bat            # Windows 一键构建入口
└── build-apk.ps1            # Gradle 检测与构建脚本
```

## 算法本地测试（可选，需电脑安装 Kotlin 命令行）

```bash
kotlinc app/src/main/java/com/screenpulse/app/UsageEngine.kt tests/UsageEngineTest.kt -include-runtime -d engine-tests.jar
java -jar engine-tests.jar
```

**开发状态**：核心事件计时算法测试通过；因当前生成环境没有 Android SDK 且无法连接外部 Android 构建仓库，尚未在真机上运行/完成 APK 构建。请通过 Android Studio 或本工程的构建脚本编译、安装进行设备验证。

## v1.0.1 (2026-10-22)
- 使用情况自动刷新时不再清空整页、不再显示全屏加载转圈；使用后台查询、原位更新总时长、当前应用、24小时图表与排行，保持页面滚动位置。
- 修复 Activity 首次打开时 onCreate/onResume 重复刷新。
