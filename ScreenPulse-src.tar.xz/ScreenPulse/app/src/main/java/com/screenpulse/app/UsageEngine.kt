package com.screenpulse.app

import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/** Pure Kotlin event reducer; it can be tested without an Android runtime. */
object UsageEngine {
    enum class Kind { RESUME, PAUSE, SCREEN_ON, SCREEN_OFF, UNLOCK, LOCK }
    data class Event(val time: Long, val packageName: String, val kind: Kind)
    data class Result(
        val appMillis: Map<String, Long>,
        val hourlyMillis: LongArray,
        val currentApp: String?,
        val currentSessionStart: Long?,
        val openings: Int
    ) {
        val totalMillis: Long get() = appMillis.values.sum()
    }

    /**
     * Events may begin before [from] to seed the foreground/screen/lock state.
     * Only sessions intersecting [from, to] are counted. Never counts background apps.
     */
    fun reduce(events: List<Event>, from: Long, to: Long): Result {
        require(from <= to)
        val durations = mutableMapOf<String, Long>()
        val bins = LongArray(24)
        var foreground: String? = null
        var activeStart: Long? = null
        var currentSessionStart: Long? = null
        var interactive = true
        var unlocked = true
        var openings = 0

        fun addDuration(pkg: String, start: Long, finish: Long) {
            val a = max(start, from)
            val b = min(finish, to)
            if (b <= a) return
            durations[pkg] = (durations[pkg] ?: 0L) + b - a
            var cursor = a
            while (cursor < b) {
                val calendar = Calendar.getInstance().apply { timeInMillis = cursor }
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                calendar.add(Calendar.HOUR_OF_DAY, 1)
                val boundary = min(b, calendar.timeInMillis)
                // Always progress, even across daylight-saving transitions.
                val next = if (boundary <= cursor) b else boundary
                bins[hour] += next - cursor
                cursor = next
            }
        }

        fun close(at: Long) {
            val pkg = foreground
            val since = activeStart
            if (pkg != null && since != null) addDuration(pkg, since, at)
            activeStart = null
            currentSessionStart = null
        }

        fun open(at: Long) {
            if (foreground != null && interactive && unlocked && activeStart == null) {
                activeStart = at
                currentSessionStart = at
            }
        }

        for (event in events) {
            if (event.time > to) break
            when (event.kind) {
                Kind.RESUME -> {
                    if (foreground != event.packageName) {
                        close(event.time)
                        foreground = event.packageName
                        if (event.time >= from) openings++
                    }
                    open(event.time)
                }
                Kind.PAUSE -> if (foreground == event.packageName) {
                    close(event.time)
                    foreground = null
                }
                Kind.SCREEN_OFF -> {
                    close(event.time)
                    interactive = false
                }
                Kind.LOCK -> {
                    close(event.time)
                    unlocked = false
                }
                Kind.SCREEN_ON -> {
                    interactive = true
                    open(event.time)
                }
                Kind.UNLOCK -> {
                    unlocked = true
                    open(event.time)
                }
            }
        }
        val pkg = foreground
        val since = activeStart
        if (pkg != null && since != null) addDuration(pkg, since, to)
        return Result(durations, bins, if (since != null) pkg else null, currentSessionStart, openings)
    }
}
