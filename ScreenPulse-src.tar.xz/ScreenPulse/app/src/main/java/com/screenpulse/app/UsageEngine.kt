package com.screenpulse.app

import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/** Reducer of system usage events; intentionally independent of Android classes for tests. */
object UsageEngine {
    enum class Kind { RESUME, PAUSE, SCREEN_ON, SCREEN_OFF, UNLOCK, LOCK }
    data class Event(val time: Long, val packageName: String, val kind: Kind)
    data class Result(
        val appMillis: Map<String, Long>,
        val hourlyMillis: LongArray,
        val currentApp: String?,
        val currentSessionStart: Long?,
        val openings: Int,
        /** Actual screen-interactive and unlocked time; NOT the sum of application times. */
        val screenMillis: Long,
        val screenHourlyMillis: LongArray,
        /** Only true when Android provided screen interactive/noninteractive events. */
        val hasScreenEvents: Boolean
    ) {
        val totalMillis: Long get() = appMillis.values.sum()
    }

    /**
     * [events] must be in ascending timestamp order. Include a preceding day to
     * reconstruct the initial power/keyguard state at [from]. Activity RESUME/PAUSE
     * events describe apps, but do not define screen-on time (these totals differ).
     */
    fun reduce(events: List<Event>, from: Long, to: Long): Result {
        require(from <= to)
        val durations = mutableMapOf<String, Long>()
        val appBins = LongArray(24)
        val screenBins = LongArray(24)
        var foreground: String? = null
        var activeStart: Long? = null
        var currentSessionStart: Long? = null
        var interactive = true // app foreground fallback when device screen events are unavailable
        var unlocked = true
        var openings = 0
        var screenInteractive: Boolean? = null
        var keyguardVisible: Boolean? = null
        var screenSince: Long? = null
        var sawScreenEvent = false

        fun splitIntoHours(start: Long, finish: Long, bins: LongArray): Long {
            val a = max(start, from)
            val b = min(finish, to)
            if (b <= a) return 0L
            var cursor = a
            while (cursor < b) {
                val calendar = Calendar.getInstance().apply { timeInMillis = cursor }
                val hour = calendar.get(Calendar.HOUR_OF_DAY)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                calendar.set(Calendar.MILLISECOND, 0)
                calendar.add(Calendar.HOUR_OF_DAY, 1)
                val boundary = min(b, calendar.timeInMillis)
                val next = if (boundary <= cursor) b else boundary
                bins[hour] += next - cursor
                cursor = next
            }
            return b - a
        }

        fun closeApp(at: Long) {
            val pkg = foreground
            val since = activeStart
            if (pkg != null && since != null) {
                val elapsed = splitIntoHours(since, at, appBins)
                if (elapsed > 0L) durations[pkg] = (durations[pkg] ?: 0L) + elapsed
            }
            activeStart = null
            currentSessionStart = null
        }
        fun openApp(at: Long) {
            if (foreground != null && interactive && unlocked && activeStart == null) {
                activeStart = at
                currentSessionStart = at
            }
        }

        var screenTime = 0L
        fun closeScreen(at: Long) {
            screenSince?.let { screenTime += splitIntoHours(it, at, screenBins) }
            screenSince = null
        }
        fun openScreen(at: Long) {
            if (screenInteractive == true && keyguardVisible != true && screenSince == null) {
                screenSince = at
            }
        }

        for (event in events) {
            if (event.time > to) break
            when (event.kind) {
                Kind.RESUME -> {
                    if (foreground != event.packageName) {
                        closeApp(event.time)
                        foreground = event.packageName
                        if (event.time >= from) openings++
                    }
                    openApp(event.time)
                }
                Kind.PAUSE -> if (foreground == event.packageName) {
                    closeApp(event.time)
                    foreground = null
                }
                Kind.SCREEN_OFF -> {
                    sawScreenEvent = true
                    closeApp(event.time)
                    closeScreen(event.time)
                    interactive = false
                    screenInteractive = false
                }
                Kind.LOCK -> {
                    closeApp(event.time)
                    closeScreen(event.time)
                    unlocked = false
                    keyguardVisible = true
                }
                Kind.SCREEN_ON -> {
                    sawScreenEvent = true
                    interactive = true
                    screenInteractive = true
                    openApp(event.time)
                    openScreen(event.time)
                }
                Kind.UNLOCK -> {
                    unlocked = true
                    keyguardVisible = false
                    openApp(event.time)
                    openScreen(event.time)
                }
            }
        }
        val pkg = foreground
        activeStart?.let { since ->
            if (pkg != null) {
                val elapsed = splitIntoHours(since, to, appBins)
                if (elapsed > 0) durations[pkg] = (durations[pkg] ?: 0L) + elapsed
            }
        }
        closeScreen(to)
        // The two streams can differ, but device time must never exceed the real elapsed day.
        return Result(durations, appBins, if (activeStart != null) pkg else null,
            currentSessionStart, openings, screenTime, screenBins, sawScreenEvent)
    }
}
