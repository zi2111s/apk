package com.screenpulse.app

import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/** Foreground event reducer. The hourly bars intentionally describe observed events only. */
object UsageEngine {
    enum class Kind { RESUME, PAUSE, SCREEN_ON, SCREEN_OFF, UNLOCK, LOCK }
    /** Activity identifies which window paused; Android can pause the old Activity after a new one resumes. */
    data class Event(val time: Long, val packageName: String, val kind: Kind, val activity: String = "")
    data class Result(
        val appMillis: Map<String, Long>,
        val hourlyMillis: LongArray,
        val currentApp: String?,
        val currentSessionStart: Long?,
        val openings: Int,
        val screenMillis: Long,
        val screenHourlyMillis: LongArray,
        val hasScreenEvents: Boolean
    ) {
        val totalMillis: Long get() = appMillis.values.sum()
    }

    fun reduce(events: List<Event>, from: Long, to: Long): Result {
        require(from <= to)
        val durations = mutableMapOf<String, Long>()
        val appBins = LongArray(24)
        val screenBins = LongArray(24)
        var foreground: String? = null
        var activeActivity: String? = null
        val resumedActivities = linkedSetOf<String>()
        var activeStart: Long? = null
        var currentSessionStart: Long? = null
        var interactive = true
        var unlocked = true
        var openings = 0
        var screenInteractive: Boolean? = null
        var keyguardVisible: Boolean? = null
        var screenSince: Long? = null
        var sawScreenEvent = false
        var screenTime = 0L

        fun splitIntoHours(start: Long, finish: Long, bins: LongArray): Long {
            val a = max(start, from)
            val b = min(finish, to)
            if (b <= a) return 0L
            var cursor = a
            while (cursor < b) {
                val cal = Calendar.getInstance().apply { timeInMillis = cursor }
                val hour = cal.get(Calendar.HOUR_OF_DAY)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.set(Calendar.MILLISECOND, 0)
                cal.add(Calendar.HOUR_OF_DAY, 1)
                val boundary = min(b, cal.timeInMillis)
                val next = if (boundary <= cursor) b else boundary
                bins[hour] += next - cursor
                cursor = next
            }
            return b - a
        }

        fun closeApp(at: Long) {
            val pkg = foreground
            val since = activeStart
            if (pkg != null && since != null) {
                val elapsed = splitIntoHours(since, at, appBins)
                if (elapsed > 0L) durations[pkg] = (durations[pkg] ?: 0L) + elapsed
            }
            activeStart = null
            currentSessionStart = null
        }
        fun openApp(at: Long) {
            if (foreground != null && interactive && unlocked && activeStart == null) {
                activeStart = at
                currentSessionStart = at
            }
        }
        fun closeScreen(at: Long) {
            screenSince?.let { screenTime += splitIntoHours(it, at, screenBins) }
            screenSince = null
        }
        fun openScreen(at: Long) {
            if (screenInteractive == true && keyguardVisible != true && screenSince == null) {
                screenSince = at
            }
        }
        // Android already yields sorted events; a stable sort also handles OEM out-of-order records.
        for (event in events.sortedBy { it.time }) {
            if (event.time > to) break
            when (event.kind) {
                Kind.RESUME -> {
                    if (event.packageName.isBlank()) continue
                    val pkg = event.packageName
                    if (foreground != pkg) {
                        closeApp(event.time)
                        foreground = pkg
                        resumedActivities.clear()
                        if (event.time >= from) openings++
                    }
                    // A new resumed Activity proves the user is in an unlocked foreground app,
                    // even if the OEM omitted KEYGUARD_HIDDEN after KEYGUARD_SHOWN.
                    unlocked = true
                    interactive = true
                    // No SCREEN_INTERACTIVE event was seen yet (e.g. after midnight).
                    // A user-visible RESUME provides an on-screen lower-bound.
                    if (screenInteractive == null) screenInteractive = true
                    if (pkg != "com.android.systemui") keyguardVisible = false
                    val activityKey = event.activity.ifBlank { "#unknown" }
                    resumedActivities.remove(activityKey)
                    resumedActivities.add(activityKey)
                    activeActivity = activityKey
                    openApp(event.time)
                    openScreen(event.time)
                }
                Kind.PAUSE -> if (foreground == event.packageName) {
                    val activityKey = event.activity.ifBlank { "#unknown" }
                    if (resumedActivities.contains(activityKey)) {
                        resumedActivities.remove(activityKey)
                        if (resumedActivities.isNotEmpty()) {
                            // A previous Activity was paused after the next one resumed.
                            if (activeActivity == activityKey) activeActivity = resumedActivities.last()
                        } else {
                            closeApp(event.time)
                            foreground = null
                            activeActivity = null
                        }
                    } else if (resumedActivities.isEmpty()) {
                        closeApp(event.time)
                        foreground = null
                        activeActivity = null
                    }
                    // Stale PAUSE for a different Activity must never close the new one.
                }
                Kind.SCREEN_OFF -> {
                    sawScreenEvent = true
                    closeApp(event.time)
                    closeScreen(event.time)
                    interactive = false
                    screenInteractive = false
                }
                Kind.LOCK -> {
                    closeApp(event.time)
                    closeScreen(event.time)
                    unlocked = false
                    keyguardVisible = true
                }
                Kind.SCREEN_ON -> {
                    sawScreenEvent = true
                    interactive = true
                    screenInteractive = true
                    openApp(event.time)
                    openScreen(event.time)
                }
                Kind.UNLOCK -> {
                    unlocked = true
                    keyguardVisible = false
                    openApp(event.time)
                    openScreen(event.time)
                }
            }
        }
        val pkg = foreground
        activeStart?.let { since ->
            if (pkg != null) {
                val elapsed = splitIntoHours(since, to, appBins)
                if (elapsed > 0) durations[pkg] = (durations[pkg] ?: 0L) + elapsed
            }
        }
        closeScreen(to)
        return Result(durations, appBins, if (activeStart != null) pkg else null,
            currentSessionStart, openings, screenTime, screenBins, sawScreenEvent)
    }
}
