package com.screenpulse.app

/** Stable presentation rules; cross-source larger-is-better is deliberately forbidden. */
object UsageSourcePolicy {
    /** Unknown days are missing observations, never assumed to mean zero minutes. */
    fun reliableAverage(days: List<Pair<Boolean, Long>>): Long? {
        if (days.isEmpty()) return null
        val required = if (days.size <= 7) minOf(5, days.size) else (days.size * 0.7).toInt()
        val known = days.filter { it.first }
        return if (known.size >= required) known.sumOf { it.second } / known.size else null
    }
}
