package com.screenpulse.app

/** Decide which *real* Android API result is usable; never synthesize missing minutes. */
object UsageSourcePolicy {
    fun preferDaily(eventTotal: Long, dailyTotal: Long, elapsed: Long): Boolean {
        if (dailyTotal <= 0L || elapsed <= 0L || dailyTotal > elapsed + 120_000L) return false
        return dailyTotal > eventTotal
    }

    /** Require broad coverage; unknown past days must not become artificial zeroes. */
    fun reliableAverage(days: List<Pair<Boolean, Long>>): Long? {
        if (days.isEmpty()) return null
        val required = if (days.size <= 7) minOf(5, days.size) else (days.size * 0.7).toInt()
        val known = days.filter { it.first }
        return if (known.size >= required) known.sumOf { it.second } / known.size else null
    }
}
