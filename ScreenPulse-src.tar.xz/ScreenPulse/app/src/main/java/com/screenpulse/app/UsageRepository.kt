package com.screenpulse.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.min

class UsageRepository(private val context: Context) {
    data class DayReport(
        val start: Long,
        val end: Long,
        val appMillis: Map<String, Long>,
        val hourlyMillis: LongArray,
        val activeApp: String?,
        val currentSessionStart: Long?,
        val launches: Int,
        val estimatedFromDailyBuckets: Boolean,
        /** True only if SCREEN_INTERACTIVE / SCREEN_NON_INTERACTIVE were present. */
        val screenBased: Boolean
    ) {
        // One consistent denominator for main total, hourly chart and app ranking.
        // Do not use screen-interactive events as the headline: OEMs vary widely
        // in whether and when those events are emitted.
        val totalMillis: Long get() = appMillis.values.sum()
        var deviceMillis: Long = 0L
    }

    private val statsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    fun hasUsagePermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getDay(offset: Int = 0): DayReport {
        require(offset in 0..365)
        val now = System.currentTimeMillis()
        val startCal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -offset)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = startCal.timeInMillis
        startCal.add(Calendar.DAY_OF_YEAR, 1)
        val end = min(startCal.timeInMillis, now)
        if (!hasUsagePermission() || end <= start) {
            return DayReport(start, end, emptyMap(), LongArray(24), null, null, 0, false, false)
        }

        // Event history is short-lived on Android. Use it only for the recent days,
        // Older dates may lack complete screen events. Only show bucket data as estimates.
        if (offset <= 10) {
            try {
                val events = getEvents(start - 24 * 60 * 60 * 1000L, end)
                val summary = UsageEngine.reduce(events, start, end)
                if (summary.totalMillis > 0L) {
                    return DayReport(start, end, summary.appMillis,
                        summary.hourlyMillis,
                        summary.currentApp, summary.currentSessionStart,
                        summary.openings, false, true
                    ).apply { deviceMillis = summary.screenMillis }
                }
            } catch (_: SecurityException) { /* Permission may be revoked while reading. */ }
        }

        // Fallback: totalTimeInForeground is not exact live data and could differ
        // slightly from OEM Digital Wellbeing. Clearly mark it as an estimate.
        val byApp = mutableMapOf<String, Long>()
        try {
            for (stat in statsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end).orEmpty()) {
                if (stat.totalTimeInForeground <= 0) continue
                val millis = stat.totalTimeInForeground.coerceAtMost(end - start)
                // Android can return overlapping daily buckets; never add them
                // blindly (the previous version inflated historical averages).
                byApp[stat.packageName] = maxOf(byApp[stat.packageName] ?: 0L, millis)
            }
        } catch (_: SecurityException) { /* Permission revoked. */ }
        // Enforce a physically possible single-device total on fallback data.
        // Each app remains a proportional estimate if daily buckets overlap.
        val summed = byApp.values.sum()
        val available = (end - start).coerceAtLeast(0L)
        val fallback = if (summed > available && available > 0L) {
            val ratio = available.toDouble() / summed
            byApp.mapValues { (_, time) -> (time * ratio).toLong() }
        } else byApp
        return DayReport(start, end, fallback, LongArray(24), null, null, 0, true, false)
    }

    private fun getEvents(from: Long, to: Long): List<UsageEngine.Event> {
        val usageEvents = statsManager.queryEvents(from, to) ?: return emptyList()
        val events = ArrayList<UsageEngine.Event>()
        val event = UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            val kind = when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> UsageEngine.Kind.RESUME
                UsageEvents.Event.ACTIVITY_PAUSED -> UsageEngine.Kind.PAUSE
                UsageEvents.Event.SCREEN_INTERACTIVE -> UsageEngine.Kind.SCREEN_ON
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> UsageEngine.Kind.SCREEN_OFF
                UsageEvents.Event.KEYGUARD_HIDDEN -> UsageEngine.Kind.UNLOCK
                UsageEvents.Event.KEYGUARD_SHOWN -> UsageEngine.Kind.LOCK
                else -> null
            }
            if (kind != null) {
                events += UsageEngine.Event(event.timeStamp, event.packageName.orEmpty(), kind)
            }
        }
        return events
    }

    fun appName(packageName: String): String {
        return try {
            val app = if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getApplicationInfo(
                    packageName, PackageManager.ApplicationInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getApplicationInfo(packageName, 0)
            }
            context.packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) {
            packageName.substringAfterLast('.')
        }
    }

    fun appIcon(packageName: String): android.graphics.drawable.Drawable? = try {
        context.packageManager.getApplicationIcon(packageName)
    } catch (_: Exception) { null }

    fun dateText(time: Long): String = SimpleDateFormat("M月d日 EEEE", Locale.CHINA).format(Date(time))

    companion object {
        fun duration(ms: Long): String {
            val min = (ms.coerceAtLeast(0) / 60_000)
            return if (min >= 60) "${min / 60}小时${(min % 60).toString().padStart(2, '0')}分"
            else "${min}分钟"
        }
        fun shortDuration(ms: Long): String {
            val minutes = (ms.coerceAtLeast(0) / 60_000)
            return "%02d:%02d".format(Locale.US, minutes / 60, minutes % 60)
        }
    }
}
