package com.screenpulse.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.min

class UsageRepository(private val context: Context) {
    data class DayReport(
        val start: Long,
        val end: Long,
        val appMillis: Map<String, Long>,
        val hourlyMillis: LongArray,
        val activeApp: String?,
        val currentSessionStart: Long?,
        val launches: Int,
        val estimatedFromDailyBuckets: Boolean,
        /** Whether the device emitted screen interactive events. */
        val screenBased: Boolean,
        /** Whether either source contained credible actual usage. Missing dates are unknown, not zero. */
        val hasEvidence: Boolean = false,
        /** Hourly bars can be incomplete if the main total comes from daily buckets. */
        val hourlyIncomplete: Boolean = false,
        val eventTotalMillis: Long = 0L,
        /** Unverified Android INTERVAL_DAILY total, for source comparison only. */
        val androidDailyMillis: Long? = null,
        val dailySampleCount: Int = 0
    ) {
        /** Display screen-interactive time when the phone emits usable screen events.
         * Per-app rankings intentionally remain a separate foreground-event metric. */
        val hasScreenHeadline: Boolean get() = screenBased && deviceMillis > 0L
        val totalMillis: Long get() = if (hasScreenHeadline) deviceMillis else eventTotalMillis
        var deviceMillis: Long = 0L
    }

    private val statsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    fun hasUsagePermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun getDay(offset: Int = 0): DayReport {
        require(offset in 0..365)
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -offset)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
        val end = min(cal.timeInMillis, now)
        if (!hasUsagePermission() || end <= start) {
            return DayReport(start, end, emptyMap(), LongArray(24), null, null, 0,
                false, false, false)
        }

        // Each OEM may retain ACTIVITY_RESUMED/PAUSED for different periods, or omit
        // KEYGUARD_HIDDEN. Never silently mistake missing events for a real zero.
        val engine = if (offset <= 10) {
            try { UsageEngine.reduce(getEvents(start - 24L * 60 * 60 * 1000, end), start, end) }
            catch (_: Exception) { null }
        } else null
        val observed = engine?.totalMillis ?: 0L

        // Read Android's daily aggregate for explicit diagnostics only.
        // This does not reproduce the vendor Digital Wellbeing timeline.
        val daily = linkedMapOf<String, Long>()
        var anyDaily = false
        var dailySampleCount = 0
        try {
            for (stat in statsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end).orEmpty()) {
                if (stat.totalTimeInForeground < 0L || stat.packageName.isNullOrBlank()) continue
                anyDaily = true
                dailySampleCount++
                if (stat.totalTimeInForeground == 0L) continue
                val elapsed = (end - start).coerceAtLeast(0L)
                val millis = stat.totalTimeInForeground.coerceAtMost(elapsed)
                // Overlapping buckets are duplicated on some ROMs. Pick one
                // per-package maximal reading rather than summing duplicates.
                daily[stat.packageName] = maxOf(daily[stat.packageName] ?: 0L, millis)
            }
        } catch (_: Exception) { /* Revoked permission / restricted OEM service. */ }
        val dailyTotal = daily.values.sum()
        // Do NOT promote the larger Android daily bucket to the headline/ranking.
        // INTERVAL_DAILY is aligned to system buckets; timestamps requested from the
        // API do not guarantee exact user-visible vendor Digital Wellbeing slices.
        // Earlier versions chose max(event,daily), which inflated totals and skewed
        // individual app ranking (QQ vs Xiaohongshu on Vivo). Distinct sources must
        // remain distinct: timeline/ranking/total all derive from one event reducer.
        val selected = engine?.appMillis.orEmpty()
        val sourceValid = engine != null && (observed > 0L || engine.screenMillis > 0L)
        val hourly = engine?.hourlyMillis ?: LongArray(24)
        val report = DayReport(
            start, end, selected, hourly,
            if (offset == 0) engine?.currentApp else null,
            if (offset == 0) engine?.currentSessionStart else null,
            engine?.openings ?: 0,
            false, engine?.hasScreenEvents ?: false,
            sourceValid,
            false,
            observed,
            if (anyDaily) dailyTotal else null,
            dailySampleCount
        )
        report.deviceMillis = engine?.screenMillis ?: 0L
        return report
    }

    private fun getEvents(from: Long, to: Long): List<UsageEngine.Event> {
        val usageEvents = statsManager.queryEvents(from, to) ?: return emptyList()
        val result = ArrayList<UsageEngine.Event>()
        val event = UsageEvents.Event()
        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            val kind = when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> UsageEngine.Kind.RESUME
                UsageEvents.Event.ACTIVITY_PAUSED -> UsageEngine.Kind.PAUSE
                UsageEvents.Event.SCREEN_INTERACTIVE -> UsageEngine.Kind.SCREEN_ON
                UsageEvents.Event.SCREEN_NON_INTERACTIVE -> UsageEngine.Kind.SCREEN_OFF
                UsageEvents.Event.KEYGUARD_HIDDEN -> UsageEngine.Kind.UNLOCK
                UsageEvents.Event.KEYGUARD_SHOWN -> UsageEngine.Kind.LOCK
                else -> null
            }
            if (kind != null) {
                result += UsageEngine.Event(event.timeStamp, event.packageName.orEmpty(), kind,
                    event.className.orEmpty())
            }
        }
        return result
    }

    fun appName(packageName: String): String {
        return try {
            val app = if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getApplicationInfo(
                    packageName, PackageManager.ApplicationInfoFlags.of(0L)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getApplicationInfo(packageName, 0)
            }
            context.packageManager.getApplicationLabel(app).toString()
        } catch (_: Exception) { packageName.substringAfterLast('.') }
    }

    fun appIcon(packageName: String): android.graphics.drawable.Drawable? = try {
        context.packageManager.getApplicationIcon(packageName)
    } catch (_: Exception) { null }

    fun dateText(time: Long): String = SimpleDateFormat("M月d日 EEEE", Locale.CHINA).format(Date(time))

    companion object {
        fun duration(ms: Long): String {
            val min = ms.coerceAtLeast(0) / 60_000
            return if (min >= 60) "${min / 60}小时${(min % 60).toString().padStart(2, '0')}分"
            else "${min}分钟"
        }
        fun shortDuration(ms: Long): String {
            val minutes = ms.coerceAtLeast(0) / 60_000
            return "%02d:%02d".format(Locale.US, minutes / 60, minutes % 60)
        }
    }
}
