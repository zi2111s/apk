package com.screenpulse.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.util.Calendar

/** User-controlled persistent monitor. No screenshots, network or accessibility service. */
class MonitorService : Service() {
    private lateinit var worker: HandlerThread
    private lateinit var handler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var repository: UsageRepository
    private var bubble: FloatingTimeBubble? = null
    private var isStarted = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repository = UsageRepository(this)
        worker = HandlerThread("ScreenPulse-usage-monitor")
        worker.start()
        handler = Handler(worker.looper)
        createChannels()
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("monitor_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!isStarted) {
            isStarted = true
            val starting = monitorNotification("正在读取使用情况…", "仅在本机统计，不上传数据")
            try {
                if (Build.VERSION.SDK_INT >= 34) {
                    startForeground(1001, starting, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                } else {
                    startForeground(1001, starting)
                }
            } catch (_: Exception) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("monitor_enabled", false).apply()
                stopSelf()
                return START_NOT_STICKY
            }
            handler.post(tick)
        }
        return START_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            if (!prefs.getBoolean("monitor_enabled", false) || !repository.hasUsagePermission()) {
                stopSelf()
                return
            }
            try {
                val report = repository.getDay()
                val top = report.activeApp?.let(repository::appName) ?: "暂无前台应用"
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(1001, monitorNotification(
                    "今日 ${UsageRepository.duration(report.totalMillis)}",
                    "当前：$top · 点击查看使用排行"
                ))
                checkLimits(report, manager)
                val showBubble = prefs.getBoolean("overlay_enabled", false) && Settings.canDrawOverlays(this@MonitorService)
                mainHandler.post {
                    if (showBubble) {
                        if (bubble == null) bubble = FloatingTimeBubble(this@MonitorService)
                        bubble?.update(UsageRepository.shortDuration(report.totalMillis))
                    } else {
                        bubble?.remove()
                        bubble = null
                    }
                }
            } catch (_: Exception) {
                // OEM usage services may transiently reject queries after screen locking.
            }
            handler.postDelayed(this, 30_000L)
        }
    }

    private fun checkLimits(report: UsageRepository.DayReport, notificationManager: NotificationManager) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val dailyLimit = prefs.getInt("daily_limit_minutes", 0)
        if (dailyLimit > 0 && report.totalMillis >= dailyLimit * 60_000L) {
            val stamp = report.start
            if (prefs.getLong("daily_limit_last", -1L) != stamp) {
                prefs.edit().putLong("daily_limit_last", stamp).apply()
                alert(notificationManager, 2001, "今日使用时长已达到目标",
                    "今天已使用 ${UsageRepository.duration(report.totalMillis)}")
            }
        }
        val app = report.activeApp ?: return
        val appLimit = prefs.getInt("limit_$app", 0)
        val appDuration = report.appMillis[app] ?: 0L
        if (appLimit > 0 && appDuration >= appLimit * 60_000L) {
            val tag = "app_limit_last_$app"
            if (prefs.getLong(tag, -1L) != report.start) {
                prefs.edit().putLong(tag, report.start).apply()
                alert(notificationManager, 2002 + (app.hashCode() and 0x3ffff),
                    "${repository.appName(app)} 已到使用限额",
                    "今日已使用 ${UsageRepository.duration(appDuration)}")
            }
        }
        val breakMinutes = prefs.getInt("break_minutes", 0)
        val sessionStart = report.currentSessionStart ?: return
        if (breakMinutes > 0 && System.currentTimeMillis() - sessionStart >= breakMinutes * 60_000L) {
            val key = "last_break_session_$app"
            if (prefs.getLong(key, -1L) != sessionStart) {
                prefs.edit().putLong(key, sessionStart).apply()
                alert(notificationManager, 3002, "连续使用时间较长", "已经连续使用 $breakMinutes 分钟，可以休息一下")
            }
        }
    }

    private fun alert(manager: NotificationManager, id: Int, title: String, content: String) {
        val notification = Notification.Builder(this, "screenpulse_alerts")
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .build()
        manager.notify(id, notification)
    }

    private fun monitorNotification(title: String, content: String): Notification {
        val stopIntent = Intent(this, MonitorService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 10, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "screenpulse_monitor")
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(openAppIntent())
            .addAction(Notification.Action.Builder(null, "停止监控", stopPending).build())
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun openAppIntent(): PendingIntent {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun createChannels() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(
            "screenpulse_monitor", "实时使用时长", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "显示今日用机时长及前台应用" })
        manager.createNotificationChannel(NotificationChannel(
            "screenpulse_alerts", "使用限额提醒", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "每日目标、单个应用限额及连续使用提醒" })
    }

    override fun onDestroy() {
        running = false
        if (::handler.isInitialized) handler.removeCallbacksAndMessages(null)
        mainHandler.post { bubble?.remove(); bubble = null }
        if (::worker.isInitialized) worker.quitSafely()
        super.onDestroy()
    }

    companion object {
        const val PREFS = "screenpulse_preferences"
        private const val ACTION_STOP = "com.screenpulse.app.STOP_MONITOR"
        @Volatile var running: Boolean = false
            private set

        fun start(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean("monitor_enabled", true).apply()
            val intent = Intent(context, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }
        fun stop(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean("monitor_enabled", false).apply()
            context.stopService(Intent(context, MonitorService::class.java))
        }
    }
}

/** Optional draggable overlay. Shown only after explicit user permission and opt-in. */
class FloatingTimeBubble(private val context: Context) {
    private val manager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var added = false
    private val textView = TextView(context).apply {
        text = "00:00"
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(dp(14), dp(9), dp(14), dp(9))
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            cornerRadius = dp(25).toFloat()
            setColor(Color.rgb(30, 64, 175))
        }
        elevation = dp(8).toFloat()
    }
    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180) }

    init {
        var downX = 0f
        var downY = 0f
        var originX = 0
        var originY = 0
        var moved = false
        textView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    originX = params.x; originY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = (originX + dx).coerceAtLeast(0)
                        params.y = (originY + dy).coerceAtLeast(0)
                        try { manager.updateViewLayout(textView, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        context.startActivity(Intent(context, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    }
                    true
                }
                else -> false
            }
        }
    }
    fun update(s: String) {
        textView.text = s
        if (!added) {
            try { manager.addView(textView, params); added = true } catch (_: Exception) { }
        }
    }
    fun remove() {
        if (added) {
            try { manager.removeView(textView) } catch (_: Exception) { }
            added = false
        }
    }
    private fun dp(value: Int) = (context.resources.displayMetrics.density * value + .5f).toInt()
}
