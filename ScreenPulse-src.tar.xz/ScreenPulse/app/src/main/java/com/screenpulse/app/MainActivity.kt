package com.screenpulse.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

class MainActivity : Activity() {
    private val blue = Color.rgb(37, 99, 235)
    private val deepBlue = Color.rgb(30, 64, 175)
    private val ink = Color.rgb(22, 32, 52)
    private val muted = Color.rgb(115, 130, 153)
    private val pale = Color.rgb(246, 248, 252)
    private val line = Color.rgb(229, 234, 242)
    private val white = Color.WHITE
    private val green = Color.rgb(15, 148, 105)
    private val ui = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val serial = AtomicInteger(0)
    private lateinit var repo: UsageRepository
    private lateinit var body: FrameLayout
    private lateinit var tabs: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private var tab = 0
    private var range = 7
    private var previousScroll = 0
    private var lastWeek: List<UsageRepository.DayReport> = emptyList()
    private var lastWeekCachedAt = 0L
    private var pendingOverlayAuthorization = false
    private val prefs by lazy { getSharedPreferences(MonitorService.PREFS, MODE_PRIVATE) }

    private data class Payload(
        val today: UsageRepository.DayReport,
        val yesterday: UsageRepository.DayReport?,
        val days: List<UsageRepository.DayReport>
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UsageRepository(this)
        window.statusBarColor = pale
        window.navigationBarColor = white
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setupShell()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (pendingOverlayAuthorization && Settings.canDrawOverlays(this)) {
            pendingOverlayAuthorization = false
            prefs.edit().putBoolean("overlay_enabled", true).apply()
            if (!prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission()) {
                try { MonitorService.start(this) } catch (_: Exception) { }
            }
        }
        // Only resume a monitor that the user explicitly enabled earlier.
        if (prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission() && !MonitorService.running) {
            try { MonitorService.start(this) } catch (_: Exception) {
                prefs.edit().putBoolean("monitor_enabled", false).apply()
            }
        }
        refresh()
        ui.removeCallbacks(autoRefresh)
        ui.postDelayed(autoRefresh, 15_000L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(autoRefresh)
    }

    override fun onDestroy() {
        serial.incrementAndGet()
        executor.shutdown()
        super.onDestroy()
    }

    private val autoRefresh: Runnable = object : Runnable {
        override fun run() {
            if (tab == 0) refresh()
            ui.postDelayed(this, 15_000L)
        }
    }

    private fun setupShell() {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(18), dp(24), dp(18))
        }
        title = label("屏幕脉搏", 25f, ink, true)
        subtitle = label("你的设备使用概览", 12f, muted)
        top.addView(title)
        top.addView(subtitle)
        shell.addView(top)
        body = FrameLayout(this)
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(white)
            setPadding(dp(12), dp(6), dp(12), dp(7))
        }
        shell.addView(tabs, LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(shell)
        drawTabs()
    }

    private fun drawTabs() {
        tabs.removeAllViews()
        listOf("今日", "趋势", "设置").forEachIndexed { index, s ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener {
                    if (tab != index) {
                        tab = index
                        previousScroll = 0
                        refresh()
                    }
                }
            }
            val dot = label(listOf("◉", "▥", "⚙")[index], 18f, if (tab == index) blue else muted)
            val text = label(s, 12f, if (tab == index) blue else muted, tab == index)
            item.addView(dot)
            item.addView(text)
            tabs.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun refresh() {
        if (!::body.isInitialized) return
        val request = serial.incrementAndGet()
        drawTabs()
        title.text = when (tab) { 0 -> "屏幕脉搏"; 1 -> "使用趋势"; else -> "偏好设置" }
        subtitle.text = when (tab) {
            0 -> "真实系统使用事件 · 自动统计"
            1 -> "了解你每天使用设备的变化"
            else -> "所有统计数据仅保存在本机"
        }
        if (tab == 2) {
            showSettings()
            return
        }
        val scroll = body.getChildAt(0) as? ScrollView
        previousScroll = scroll?.scrollY ?: previousScroll
        showLoading()
        val selectedTab = tab
        val selectedRange = range
        executor.execute {
            try {
                val today = repo.getDay(0)
                val yesterday = if (selectedTab == 0) repo.getDay(1) else null
                val days = if (selectedTab == 1 || lastWeek.isEmpty() ||
                    System.currentTimeMillis() - lastWeekCachedAt > 120_000L) {
                    (selectedRange - 1 downTo 0).map { repo.getDay(it) }
                } else lastWeek
                if (selectedRange == 7) {
                    lastWeek = days
                    lastWeekCachedAt = System.currentTimeMillis()
                }
                val payload = Payload(today, yesterday, days)
                ui.post {
                    if (request != serial.get() || isFinishing || isDestroyed) return@post
                    if (selectedTab == 0) showToday(payload) else showTrends(payload)
                }
            } catch (e: Exception) {
                ui.post {
                    if (request == serial.get() && !isFinishing) showError(e.localizedMessage ?: "无法获取系统统计")
                }
            }
        }
    }

    private fun showLoading() {
        body.removeAllViews()
        val group = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.VERTICAL
        }
        val indicator = ProgressBar(this)
        group.addView(indicator, LinearLayout.LayoutParams(dp(40), dp(40)))
        group.addView(label("正在整理使用记录…", 13f, muted), LinearLayout.LayoutParams(-2, dp(46)))
        body.addView(group, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showError(message: String) {
        val column = newPage()
        column.addView(label("暂时无法读取使用记录", 18f, ink, true))
        column.addView(label(message, 13f, muted))
        val retry = primaryButton("重试") { refresh() }
        column.addView(retry)
    }

    private fun showToday(payload: Payload) {
        val day = payload.today
        val column = newPage()
        if (!repo.hasUsagePermission()) {
            permissionCard(column)
            return
        }
        val card = card()
        card.background = rounded(Color.rgb(235, 242, 255), 23)
        card.addView(label("今日前台使用总计", 14f, deepBlue, true))
        card.addView(label(UsageRepository.shortDuration(day.totalMillis), 49f, ink, true).apply {
            setPadding(0, dp(6), 0, 0)
        })
        card.addView(label("${repo.dateText(day.start)} · 每次刷新自动同步", 12f, muted))
        divider(card, 16)
        val appTitle = day.activeApp?.let(repo::appName) ?: "当前没有可识别的前台应用"
        card.addView(label("当前应用  ·  $appTitle", 13f, deepBlue))
        val cap = prefs.getInt("daily_limit_minutes", 0)
        if (cap > 0) {
            val limit = cap * 60_000L
            card.addView(progress(day.totalMillis, limit, blue), LinearLayout.LayoutParams(-1, dp(6)).apply {
                topMargin = dp(16)
            })
            card.addView(label("今日目标 ${cap} 分钟 · 已完成 ${((day.totalMillis * 100) / limit).coerceAtMost(999)}%", 11f, muted).apply {
                setPadding(0, dp(8), 0, 0)
            })
        }
        column.addView(card, pageWidth())

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stats.addView(miniStat("昨日", payload.yesterday?.let { UsageRepository.shortDuration(it.totalMillis) } ?: "—"),
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        val avg = if (payload.days.isNotEmpty()) payload.days.sumOf { it.totalMillis } / payload.days.size else 0
        stats.addView(miniStat("近${payload.days.size}天日均", UsageRepository.shortDuration(avg)),
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        column.addView(stats, pageWidth().apply { topMargin = dp(12) })

        val chart = card()
        chart.addView(sectionTitle("24小时使用分布", if (day.estimatedFromDailyBuckets) "历史聚合数据无法显示小时曲线" else "每小时前台应用累计时长"))
        if (day.hourlyMillis.any { it > 0L }) {
            chart.addView(HourChart(this, day.hourlyMillis, blue), LinearLayout.LayoutParams(-1, dp(168)))
        } else {
            chart.addView(label("暂无可用于绘图的小时级事件", 12f, muted).apply {
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, dp(80)))
        }
        column.addView(chart, pageWidth().apply { topMargin = dp(14) })

        val application = card()
        application.addView(sectionTitle("应用使用排行", "点击应用可设置每日使用限额"))
        val sorted = day.appMillis.entries.sortedByDescending { it.value }
        if (sorted.isEmpty()) {
            application.addView(label("暂无数据。请先授权使用情况访问权限。", 13f, muted))
        } else {
            val peak = sorted.first().value
            sorted.take(15).forEachIndexed { i, entry ->
                addAppRow(application, entry.key, entry.value, peak, i + 1)
            }
        }
        column.addView(application, pageWidth().apply { topMargin = dp(14) })
        column.addView(footnote("说明：统计的是应用处于前台的时长，而不是屏幕亮屏总时长。" +
            "不同手机的事件保留期限、系统应用可见性和省电策略可能造成与系统自带统计的差异。" +
            "使用记录不经网络传输。"))
        column.post { (column.parent as? ScrollView)?.scrollTo(0, previousScroll) }
    }

    private fun miniStat(caption: String, value: String): View {
        val c = card()
        c.setPadding(dp(16), dp(15), dp(12), dp(17))
        c.addView(label(caption, 12f, muted))
        c.addView(label(value, 20f, ink, true).apply { setPadding(0, dp(5), 0, 0) })
        return c
    }

    private fun addAppRow(parent: LinearLayout, pkg: String, time: Long, peak: Long, number: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(13), 0, dp(13))
            setOnClickListener { appLimitDialog(pkg) }
        }
        val img = ImageView(this)
        img.setImageDrawable(repo.appIcon(pkg) ?: getDrawable(R.drawable.ic_app))
        row.addView(img, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(12) })
        val central = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val upper = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        upper.addView(label(repo.appName(pkg), 14f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        upper.addView(label(UsageRepository.duration(time), 12f, muted))
        central.addView(upper)
        central.addView(progress(time, peak, blue), LinearLayout.LayoutParams(-1, dp(5)).apply {
            topMargin = dp(10)
        })
        val limit = prefs.getInt("limit_$pkg", 0)
        if (limit > 0) {
            central.addView(label("限额 $limit 分钟${if (time >= limit * 60_000L) " · 已达到" else ""}",
                11f, if (time >= limit * 60_000L) Color.rgb(210, 72, 61) else muted).apply {
                setPadding(0, dp(6), 0, 0)
            })
        }
        row.addView(central, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row)
        if (number < 15) parent.addView(View(this).apply { setBackgroundColor(line) },
            LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun showTrends(payload: Payload) {
        val column = newPage()
        if (!repo.hasUsagePermission()) {
            permissionCard(column)
            return
        }
        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(7, 30).forEach { amount ->
            val item = TextView(this).apply {
                text = "近${amount}天"
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(if (range == amount) white else muted)
                background = rounded(if (range == amount) blue else white, 14)
                setOnClickListener {
                    if (range != amount) {
                        range = amount
                        previousScroll = 0
                        refresh()
                    }
                }
            }
            selector.addView(item, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
        column.addView(selector, pageWidth())
        val days = payload.days
        val total = days.sumOf { it.totalMillis }
        val average = if (days.isEmpty()) 0L else total / days.size
        val trendCard = card()
        trendCard.addView(label("日均使用时长", 13f, muted))
        trendCard.addView(label(UsageRepository.shortDuration(average), 42f, ink, true))
        trendCard.addView(label("共 ${days.size} 天 · 系统历史统计", 12f, muted))
        trendCard.addView(DaysChart(this, days.map { it.totalMillis }.toLongArray(), blue),
            LinearLayout.LayoutParams(-1, dp(210)).apply { topMargin = dp(15) })
        column.addView(trendCard, pageWidth().apply { topMargin = dp(14) })
        val rows = card()
        rows.addView(sectionTitle("每日记录", "历史日期优先使用系统日统计，可能与实时值存在差异"))
        days.asReversed().forEach { day ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(12), 0, dp(12))
            }
            row.addView(label(repo.dateText(day.start), 13f, ink), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(UsageRepository.duration(day.totalMillis), 13f, blue, true))
            rows.addView(row)
            rows.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        column.addView(rows, pageWidth().apply { topMargin = dp(14) })
        column.addView(footnote("新安装后仍可查询系统保留的历史统计。部分品牌将使用事件保留较短时间；" +
            "历史日期使用系统按日汇总值时不会伪造小时明细。"))
        column.post { (column.parent as? ScrollView)?.scrollTo(0, previousScroll) }
    }

    private fun showSettings() {
        val column = newPage()
        if (!repo.hasUsagePermission()) permissionCard(column)
        val monitor = card()
        monitor.addView(sectionTitle("实时监控", "需要保持一条前台服务通知"))
        addSettingsRow(monitor, "系统使用记录访问", if (repo.hasUsagePermission()) "已授权" else "尚未授权", "查看") {
            openUsageSettings()
        }
        addSettingsRow(monitor, "状态栏实时监控", if (prefs.getBoolean("monitor_enabled", false)) "已启用 · 约30秒更新" else "未启用",
            if (prefs.getBoolean("monitor_enabled", false)) "关闭" else "开启") {
            if (prefs.getBoolean("monitor_enabled", false)) {
                MonitorService.stop(this)
                toast("已停止监控")
            } else if (!repo.hasUsagePermission()) {
                openUsageSettings()
            } else {
                askNotificationPermission()
                try { MonitorService.start(this); toast("监控已开启") }
                catch (_: Exception) { toast("系统限制启动后台服务，请检查权限") }
            }
            refresh()
        }
        addSettingsRow(monitor, "浮动计时气泡", if (prefs.getBoolean("overlay_enabled", false)) "已开启" else "未开启",
            if (prefs.getBoolean("overlay_enabled", false)) "关闭" else "开启") {
            if (prefs.getBoolean("overlay_enabled", false)) {
                prefs.edit().putBoolean("overlay_enabled", false).apply()
                refresh()
            } else if (!Settings.canDrawOverlays(this)) {
                AlertDialog.Builder(this)
                    .setTitle("允许显示在其他应用上层")
                    .setMessage("开启后可在屏幕侧边显示一个可拖动的累计使用时间气泡。此权限不读取屏幕内容。")
                    .setPositiveButton("去授权") { _, _ ->
                        pendingOverlayAuthorization = true
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")))
                    }.setNegativeButton("取消", null).show()
            } else {
                prefs.edit().putBoolean("overlay_enabled", true).apply()
                if (!prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission()) {
                    try { MonitorService.start(this) } catch (_: Exception) {}
                }
                refresh()
            }
        }
        column.addView(monitor, pageWidth())

        val goals = card()
        goals.addView(sectionTitle("使用时间提醒", "仅在开启实时监控后触发，不会强制锁定应用"))
        val daily = prefs.getInt("daily_limit_minutes", 0)
        addSettingsRow(goals, "每日总使用目标", if (daily > 0) "$daily 分钟" else "未设置", "编辑") {
            minutesDialog("每日总使用目标", "达到目标时发出一次提醒", "daily_limit_minutes", daily)
        }
        val breakTime = prefs.getInt("break_minutes", 0)
        addSettingsRow(goals, "连续使用提醒", if (breakTime > 0) "$breakTime 分钟" else "未设置", "编辑") {
            minutesDialog("连续使用提醒", "同一应用持续使用达到设定时间时提醒", "break_minutes", breakTime)
        }
        addSettingsRow(goals, "单个应用限额", "进入“今日”页面，点击任意应用设置", "查看") {
            tab = 0; previousScroll = 0; refresh()
        }
        column.addView(goals, pageWidth().apply { topMargin = dp(14) })

        val data = card()
        data.addView(sectionTitle("数据和隐私", "不要求联网，也不上传任何使用记录"))
        addSettingsRow(data, "导出近7天使用数据", "CSV 格式，可使用 Excel 打开", "导出") {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, "屏幕使用记录_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.csv")
            }
            startActivityForResult(intent, 62)
        }
        addSettingsRow(data, "系统统计说明", "权限、计算方法与误差来源", "查看") { showInfo() }
        column.addView(data, pageWidth().apply { topMargin = dp(14) })
        column.addView(footnote("屏幕脉搏 1.0 · Android 8.0 及以上\n" +
            "本应用只能提醒，不能直接替系统强制限制其他应用。后台服务可能被系统省电策略终止。"))
    }

    private fun addSettingsRow(parent: LinearLayout, name: String, description: String, buttonText: String, callback: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.setPadding(0, dp(16), 0, dp(16))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label(name, 14f, ink, true))
        details.addView(label(description, 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        val action = label(buttonText, 13f, blue, true).apply {
            setPadding(dp(10), dp(10), dp(2), dp(10))
        }
        row.addView(action)
        row.setOnClickListener { callback() }
        parent.addView(row)
        parent.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun showInfo() {
        AlertDialog.Builder(this)
            .setTitle("统计方法与隐私")
            .setMessage("通过 Android 的“使用情况访问权限”读取前台应用切换、屏幕交互及锁屏事件。" +
                "按事件重建使用区间，计算每个应用的前台时间；历史事件缺失时使用系统按日汇总值。" +
                "\n\n不同厂商的事件记录、系统自带屏幕使用时长口径和省电机制可能不同，因此数字不保证完全一致。" +
                "\n\n应用不使用网络权限，不读取屏幕图像、QQ聊天内容或其他应用中的文字。" +
                "没有额外的云端数据库。关闭监控不影响系统已保留的统计。")
            .setPositiveButton("知道了", null).show()
    }

    private fun permissionCard(column: LinearLayout) {
        val p = card()
        p.background = rounded(Color.rgb(255, 248, 231), 20)
        p.addView(label("需要授权读取使用统计", 18f, ink, true))
        p.addView(label("Android 默认禁止普通应用读取其他应用的使用记录。点击下方按钮，" +
            "在系统设置中找到“屏幕脉搏”，允许“使用情况访问”。", 13f, muted).apply {
            setPadding(0, dp(10), 0, dp(14))
        })
        p.addView(primaryButton("打开使用情况访问设置") { openUsageSettings() })
        column.addView(p, pageWidth())
    }

    private fun appLimitDialog(pkg: String) {
        val current = prefs.getInt("limit_$pkg", 0)
        minutesDialog("${repo.appName(pkg)} 的每日限额", "达到此应用的时长后通知一次", "limit_$pkg", current)
    }

    private fun minutesDialog(heading: String, hint: String, prefName: String, current: Int) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(if (current > 0) current.toString() else "")
            this.hint = "例如：60（分钟）"
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(heading)
            .setMessage(hint + "。输入1–1440分钟；选择“清除”可关闭此提醒。")
            .setView(input)
            .setNegativeButton("取消", null)
            .setNeutralButton("清除") { _, _ ->
                prefs.edit().remove(prefName).apply()
                refresh()
            }
            .setPositiveButton("保存", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = input.text.toString().toIntOrNull()
                if (n == null || n !in 1..1440) {
                    input.error = "请输入1至1440之间的整数"
                } else {
                    prefs.edit().putInt(prefName, n).apply()
                    dialog.dismiss()
                    refresh()
                }
            }
        }
        dialog.show()
    }

    private fun openUsageSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 63)
        }
    }

    @Deprecated("Used solely for the system's ACTION_CREATE_DOCUMENT result on Android 8+.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 62 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        toast("正在导出…")
        executor.execute {
            try {
                val csv = StringBuilder("\uFEFF日期,应用,包名,使用分钟,使用秒数\r\n")
                for (offset in 6 downTo 0) {
                    val day = repo.getDay(offset)
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(day.start))
                    day.appMillis.entries.sortedByDescending { it.value }.forEach { (pkg, ms) ->
                        fun q(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
                        csv.append("$date,${q(repo.appName(pkg))},${q(pkg)},${ms / 60_000},${ms / 1000}\r\n")
                    }
                }
                contentResolver.openOutputStream(uri)?.use { it.write(csv.toString().toByteArray(Charsets.UTF_8)) }
                    ?: error("无法写入所选文件")
                ui.post { toast("CSV 导出完成") }
            } catch (e: Exception) {
                ui.post { toast("导出失败：${e.localizedMessage}") }
            }
        }
    }

    // ----- Presentation helpers -----
    private fun newPage(): LinearLayout {
        body.removeAllViews()
        val scroller = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(4), dp(18), dp(35))
        }
        scroller.addView(column, ViewGroup.LayoutParams(-1, -2))
        body.addView(scroller, FrameLayout.LayoutParams(-1, -1))
        return column
    }
    private fun pageWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(19), dp(19), dp(19), dp(19))
        background = rounded(white, 22)
        elevation = dp(1).toFloat()
    }
    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        includeFontPadding = false
        setLineSpacing(dp(2).toFloat(), 1f)
    }
    private fun sectionTitle(name: String, description: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(name, 17f, ink, true))
        addView(label(description, 11f, muted).apply { setPadding(0, dp(4), 0, dp(14)) })
    }
    private fun divider(container: LinearLayout, margin: Int) {
        container.addView(View(this).apply { setBackgroundColor(Color.rgb(212, 224, 247)) },
            LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(margin); bottomMargin = dp(margin)
            })
    }
    private fun primaryButton(s: String, onClick: () -> Unit): View = TextView(this).apply {
        text = s
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = rounded(blue, 12)
        setOnClickListener { onClick() }
    }
    private fun footnote(s: String): View = label(s, 11f, muted).apply {
        setPadding(dp(7), dp(18), dp(7), dp(5))
    }
    private fun progress(current: Long, target: Long, tint: Int): ProgressBar =
        ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = if (target <= 0) 0 else ((current.toDouble() / target * 1000).toInt()).coerceIn(0, 1000)
            progressTintList = ColorStateList.valueOf(tint)
            progressBackgroundTintList = ColorStateList.valueOf(line)
        }
    private fun dp(i: Int): Int = (resources.displayMetrics.density * i + 0.5f).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Compact hour-level bar chart, no third-party UI/chart dependencies. */
class HourChart(context: Context, private val millis: LongArray, private val tint: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 145, 160); textSize = sp(10f) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val l = dp(3f)
        val r = width - dp(3f)
        val top = dp(12f)
        val baseline = height - dp(27f)
        val area = baseline - top
        val maxValue = max(60_000L, millis.maxOrNull() ?: 0L)
        paint.color = Color.rgb(235, 239, 246)
        paint.strokeWidth = dp(1f)
        for (i in 0..3) {
            val yy = top + area * i / 3f
            canvas.drawLine(l, yy, r, yy, paint)
        }
        val segment = (r - l) / 24f
        millis.forEachIndexed { i, v ->
            val h = area * (v.toFloat() / maxValue)
            val x = l + segment * (i + .18f)
            paint.color = tint
            canvas.drawRoundRect(x, baseline - h, x + segment * .64f, baseline, dp(3f), dp(3f), paint)
        }
        for (hour in listOf(0, 6, 12, 18, 23)) {
            val s = "%02d".format(Locale.US, hour)
            val x = (l + segment * (hour + .5f) - label.measureText(s) / 2).coerceAtLeast(0f)
            canvas.drawText(s, x, height - dp(5f), label)
        }
    }
    private fun dp(i: Float) = i * resources.displayMetrics.density
    private fun sp(i: Float) = i * resources.displayMetrics.scaledDensity
}

class DaysChart(context: Context, private val times: LongArray, private val tint: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 145, 160); textSize = sp(10f) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (times.isEmpty()) return
        val left = dp(8f)
        val right = width - dp(8f)
        val top = dp(11f)
        val bottom = height - dp(28f)
        val available = bottom - top
        val maxValue = max(times.maxOrNull() ?: 0L, 60_000L)
        p.color = Color.rgb(235, 239, 246)
        for (i in 0..3) {
            val yy = top + available * i / 3f
            canvas.drawLine(left, yy, right, yy, p)
        }
        val widthEach = (right - left) / times.size
        times.forEachIndexed { index, ms ->
            val x = left + widthEach * (index + .16f)
            val barHeight = available * (ms.toFloat() / maxValue)
            p.color = tint
            canvas.drawRoundRect(x, bottom - barHeight, x + widthEach * .68f,
                bottom, dp(if (times.size > 10) 2f else 4f), dp(4f), p)
        }
        val every = when {
            times.size <= 7 -> 1
            times.size <= 14 -> 3
            else -> 6
        }
        times.indices.filter { it % every == 0 || it == times.lastIndex }.forEach { index ->
            val s = "${index + 1}"
            val x = left + widthEach * (index + .5f) - label.measureText(s) / 2
            canvas.drawText(s, x, height - dp(6f), label)
        }
    }
    private fun dp(i: Float) = i * resources.displayMetrics.density
    private fun sp(i: Float) = i * resources.displayMetrics.scaledDensity
}
