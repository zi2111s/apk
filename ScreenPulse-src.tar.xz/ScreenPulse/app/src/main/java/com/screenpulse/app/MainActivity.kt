package com.screenpulse.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

class MainActivity : Activity() {
    private val blue = Color.rgb(17, 151, 166)
    private val deepBlue = Color.rgb(9, 106, 131)
    private val ink = Color.rgb(26, 42, 62)
    private val muted = Color.rgb(115, 134, 149)
    private val pale = Color.rgb(247, 249, 249)
    private val line = Color.rgb(230, 236, 237)
    private val white = Color.WHITE
    private val green = Color.rgb(22, 161, 136)
    private val ui = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val serial = AtomicInteger(0)
    private lateinit var repo: UsageRepository
    private lateinit var body: FrameLayout
    private lateinit var tabs: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private var tab = 0
    private var range = 7
    private var previousScroll = 0
    private var lastWeek: List<UsageRepository.DayReport> = emptyList()
    private var lastWeekCachedAt = 0L
    private var pendingOverlayAuthorization = false
    private val prefs by lazy { getSharedPreferences(MonitorService.PREFS, MODE_PRIVATE) }

    private data class Payload(
        val today: UsageRepository.DayReport,
        val yesterday: UsageRepository.DayReport?,
        val days: List<UsageRepository.DayReport>
    )

    // Keep the existing page attached during the 15-second background refresh.
    // Only the data-bound widgets are updated; the ScrollView and cards stay put.
    private data class AppBinding(
        val time: TextView,
        val bar: ProgressBar,
        val limit: TextView?
    )

    private data class TodayBinding(
        val dayStart: Long,
        val scroller: ScrollView,
        val total: TextView,
        val date: TextView,
        val active: TextView,
        val goalBar: ProgressBar?,
        val goalCaption: TextView?,
        val heroRing: UsageRingView,
        val yesterday: TextView,
        val average: TextView,
        val hourly: HourChart,
        val chartHint: TextView,
        val appCard: LinearLayout,
        val rows: MutableMap<String, AppBinding>,
        val sourceDetails: TextView,
        var order: List<String>
    )

    private var todayBinding: TodayBinding? = null
    private var drawnTab = -1
    private var lastRenderedPermission = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = UsageRepository(this)
        window.statusBarColor = pale
        window.navigationBarColor = white
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setupShell()
    }

    override fun onResume() {
        super.onResume()
        if (pendingOverlayAuthorization && Settings.canDrawOverlays(this)) {
            pendingOverlayAuthorization = false
            prefs.edit().putBoolean("overlay_enabled", true).apply()
            if (!prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission()) {
                try { MonitorService.start(this) } catch (_: Exception) { }
            }
        }
        // Only resume a monitor that the user explicitly enabled earlier.
        if (prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission() && !MonitorService.running) {
            try { MonitorService.start(this) } catch (_: Exception) {
                prefs.edit().putBoolean("monitor_enabled", false).apply()
            }
        }
        refresh()
        ui.removeCallbacks(autoRefresh)
        ui.postDelayed(autoRefresh, 15_000L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(autoRefresh)
    }

    override fun onDestroy() {
        serial.incrementAndGet()
        executor.shutdown()
        super.onDestroy()
    }

    private val autoRefresh: Runnable = object : Runnable {
        override fun run() {
            if (tab == 0) refresh()
            ui.postDelayed(this, 15_000L)
        }
    }

    private fun setupShell() {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(15))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val eyebrow = label("S C R E E N  /  P U L S E", 9f, blue, true)
        brand.addView(eyebrow)
        title = label("屏幕脉搏", 26f, ink, true).apply { setPadding(0, dp(5), 0, 0) }
        subtitle = label("把注意力留给重要的事", 12f, muted).apply { setPadding(0, dp(5), 0, 0) }
        brand.addView(title)
        brand.addView(subtitle)
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val headerEmblem = label("≈", 29f, white, true).apply {
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(57, 188, 191), Color.rgb(24, 120, 172))).apply {
                cornerRadius = dp(19).toFloat()
            }
        }
        top.addView(headerEmblem, LinearLayout.LayoutParams(dp(52), dp(52)))
        shell.addView(top)
        body = FrameLayout(this)
        shell.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(white)
            setPadding(dp(18), dp(6), dp(18), dp(6))
            elevation = dp(7).toFloat()
        }
        shell.addView(tabs, LinearLayout.LayoutParams(-1, dp(69)))
        setContentView(shell)
        drawTabs()
    }

    private fun drawTabs() {
        if (drawnTab == tab) return
        drawnTab = tab
        tabs.removeAllViews()
        listOf("今日", "趋势", "设置").forEachIndexed { index, text ->
            val selected = tab == index
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                background = rounded(if (selected) Color.rgb(229, 248, 248) else white, 19)
                setOnClickListener {
                    if (tab != index) {
                        tab = index
                        previousScroll = 0
                        refresh()
                    }
                }
            }
            val symbol = label(listOf("◉", "▥", "⚙")[index], 19f, if (selected) blue else muted, selected)
            item.addView(symbol)
            item.addView(label(text, 13f, if (selected) deepBlue else muted, selected).apply {
                setPadding(dp(7), 0, 0, 0)
            })
            tabs.addView(item, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
    }

    private fun refresh() {
        if (!::body.isInitialized) return
        val request = serial.incrementAndGet()
        drawTabs()
        title.text = when (tab) { 0 -> "屏幕脉搏"; 1 -> "时间趋势"; else -> "偏好设置" }
        subtitle.text = when (tab) {
            0 -> "看清日常，把时间还给自己"
            1 -> "发现时间流向，形成自己的节奏"
            else -> "贴合你的使用习惯，专注不受打扰"
        }
        if (tab == 2) {
            showSettings()
            return
        }
        val scroll = body.getChildAt(0) as? ScrollView
        previousScroll = scroll?.scrollY ?: previousScroll
        // Show the spinner only on a completely empty first launch. Never clear
        // the existing page while UsageStatsManager performs disk-backed queries.
        if (body.childCount == 0) showLoading()
        val selectedTab = tab
        val selectedRange = range
        executor.execute {
            try {
                val today = repo.getDay(0)
                val yesterday = if (selectedTab == 0) repo.getDay(1) else null
                // Cache HISTORICAL days only. Never reuse a zero/old "today" bucket
                // from before Usage Access was granted (previously showed 00:00
                // weekly average even when the headline was already nonzero).
                val cachedDays = lastWeek
                val cacheValid = selectedRange == 7 && selectedTab == 0 &&
                    cachedDays.size == 7 && cachedDays.lastOrNull()?.start == today.start &&
                    System.currentTimeMillis() - lastWeekCachedAt < 120_000L &&
                    cachedDays.dropLast(1).any { it.hasEvidence }
                val days = if (cacheValid) {
                    cachedDays.dropLast(1) + today
                } else {
                    (selectedRange - 1 downTo 1).map { offset ->
                        if (offset == 1 && yesterday != null) yesterday else repo.getDay(offset)
                    } + today
                }
                if (selectedRange == 7) {
                    lastWeek = days
                    lastWeekCachedAt = System.currentTimeMillis()
                }
                val payload = Payload(today, yesterday, days)
                ui.post {
                    if (request != serial.get() || isFinishing || isDestroyed) return@post
                    if (selectedTab == 0) showToday(payload) else showTrends(payload)
                }
            } catch (e: Exception) {
                ui.post {
                    if (request == serial.get() && !isFinishing) {
                        // Keep the last good values visible on transient read errors.
                        if (body.getChildAt(0) !is ScrollView)
                            showError(e.localizedMessage ?: "无法获取系统统计")
                        else android.util.Log.w("ScreenPulse", "Usage refresh failed", e)
                    }
                }
            }
        }
    }

    private fun showLoading() {
        body.removeAllViews()
        val group = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.VERTICAL
        }
        val indicator = ProgressBar(this)
        group.addView(indicator, LinearLayout.LayoutParams(dp(40), dp(40)))
        group.addView(label("正在整理使用记录…", 13f, muted), LinearLayout.LayoutParams(-2, dp(46)))
        body.addView(group, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showError(message: String) {
        val column = newPage()
        column.addView(label("暂时无法读取使用记录", 18f, ink, true))
        column.addView(label(message, 13f, muted))
        val retry = primaryButton("重试") { refresh() }
        column.addView(retry)
    }

    private fun showToday(payload: Payload) {
        val day = payload.today
        val previous = todayBinding
        if (previous != null && previous.dayStart == day.start &&
            body.getChildAt(0) === previous.scroller && repo.hasUsagePermission()) {
            updateToday(payload, previous)
            return
        }
        val column = newPage()
        if (!repo.hasUsagePermission()) {
            permissionCard(column)
            return
        }
        val meta = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(1), dp(12))
        }
        meta.addView(label("TODAY / 今日概览", 10f, deepBlue, true), LinearLayout.LayoutParams(0, -2, 1f))
        meta.addView(label(repo.dateText(day.start), 11f, muted))
        column.addView(meta)

        val hero = card().apply {
            setPadding(dp(21), dp(22), dp(21), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(227, 244, 248), Color.rgb(239, 249, 247))).apply {
                cornerRadius = dp(26).toFloat()
            }
        }
        hero.addView(label("今日 · 设备屏幕交互", 13f, deepBlue, true))
        val heroRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val numberCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val totalText = label(UsageRepository.shortDuration(day.totalMillis), 43f, ink, true).apply {
            setPadding(0, dp(11), 0, dp(1))
            letterSpacing = -0.035f
        }
        numberCol.addView(totalText)
        val dateText = label(headlineSource(day), 11f, muted)
        numberCol.addView(dateText)
        heroRow.addView(numberCol, LinearLayout.LayoutParams(0, -2, 1f))
        val goalMinutes = prefs.getInt("daily_limit_minutes", 0)
        val ring = UsageRingView(this, if (goalMinutes > 0) day.totalMillis.toFloat() / (goalMinutes * 60_000f) else 0f)
        heroRow.addView(ring, LinearLayout.LayoutParams(dp(83), dp(83)).apply { leftMargin = dp(8) })
        hero.addView(heroRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        hero.addView(View(this).apply { setBackgroundColor(Color.rgb(204, 227, 233)) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(19); bottomMargin = dp(14) })
        val appText = day.activeApp?.let(repo::appName) ?: "未识别到当前前台应用"
        val active = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val activePill = label("●", 12f, green).apply { setPadding(0, 0, dp(7), 0) }
        active.addView(activePill)
        val currentText = label("当前使用  ·  $appText", 12f, deepBlue, true)
        active.addView(currentText)
        hero.addView(active)
        var goalBar: ProgressBar? = null
        var goalCaption: TextView? = null
        if (goalMinutes > 0) {
            goalBar = progress(day.totalMillis, goalMinutes * 60_000L, blue)
            hero.addView(goalBar, LinearLayout.LayoutParams(-1, dp(5)).apply { topMargin = dp(13) })
            goalCaption = label("今日目标 ${goalMinutes} 分钟 · ${((day.totalMillis * 100) / (goalMinutes * 60_000L)).coerceAtMost(999)}%", 11f, muted)
            hero.addView(goalCaption, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        } else {
            hero.addView(label("设定每日目标，让时间流动更有方向  →", 11f, deepBlue).apply {
                setPadding(0, dp(12), 0, 0)
                setOnClickListener { tab = 2; previousScroll = 0; refresh() }
            })
        }
        column.addView(hero, pageWidth())

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val yesterdayText = label(yesterdayDisplay(day, payload.yesterday), 21f, ink, true)
        stats.addView(miniStat("昨日使用", yesterdayText, "↘"), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        val avg = reliableAverage(payload.days)
        val averageText = label(avg?.let(UsageRepository::shortDuration) ?: "—", 21f, ink, true)
        stats.addView(miniStat("近${payload.days.size}日平均", averageText, "▥"), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        column.addView(stats, pageWidth().apply { topMargin = dp(13) })

        val chart = card()
        chart.addView(sectionTitle("24 小时前台事件分布", "不等于屏幕交互时长；仅统计可观察应用事件", "◷"))
        val hourChart = HourChart(this, day.hourlyMillis.copyOf(), blue)
        chart.addView(hourChart, LinearLayout.LayoutParams(-1, dp(178)))
        val chartHint = label("系统只返回日累计，未提供可靠的小时记录", 12f, muted).apply {
            gravity = Gravity.CENTER
            visibility = if (day.hourlyMillis.any { it > 0L }) View.GONE else View.VISIBLE
        }
        chart.addView(chartHint)
        column.addView(chart, pageWidth().apply { topMargin = dp(16) })

        val application = card()
        application.addView(sectionTitle("应用前台事件排行", "来自活动切换事件，可能因系统漏报而偏低", "◈"))
        val rows = mutableMapOf<String, AppBinding>()
        val sorted = day.appMillis.entries.sortedByDescending { it.value }.take(15)
        updateRankings(application, sorted, rows, emptyList())
        column.addView(application, pageWidth().apply { topMargin = dp(16) })
        val sourceCard = card()
        sourceCard.addView(sectionTitle("为什么与系统不同？", "公开接口统计来源对照 · 不混合、也不取最大值", "◎"))
        val sourceDetails = label(sourceDescription(day), 12f, muted).apply {
            setLineSpacing(dp(4).toFloat(), 1f)
        }
        sourceCard.addView(sourceDetails, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        column.addView(sourceCard, pageWidth().apply { topMargin = dp(16) })
        column.addView(footnote("特别说明：vivo 健康使用设备使用的厂商统计口径无法通过 Android 公共接口完全复现。" +
            "屏幕交互事件、前台应用切换、系统日汇总各有不同含义，不能直接按数值大小拼接。" +
            "本软件不再宣称数字等于 vivo 官方统计。历史记录或事件缺失时显示 —，不显示虚构结果。"))
        val scroller = body.getChildAt(0) as ScrollView
        todayBinding = TodayBinding(day.start, scroller, totalText, dateText, currentText,
            goalBar, goalCaption, ring, yesterdayText, averageText, hourChart, chartHint,
            application, rows, sourceDetails, sorted.map { it.key })
        column.post { (column.parent as? ScrollView)?.scrollTo(0, previousScroll) }
    }

    // Only compare historical days with the same source as today's headline.
    // Never equate an aggregate bucket with interactive duration or foreground events.
    private fun reliableAverage(days: List<UsageRepository.DayReport>): Long? {
        val today = days.lastOrNull() ?: return null
        return UsageSourcePolicy.reliableAverage(days.map {
            (it.hasEvidence && it.hasScreenHeadline == today.hasScreenHeadline) to it.totalMillis
        })
    }

    private fun yesterdayDisplay(today: UsageRepository.DayReport, yesterday: UsageRepository.DayReport?): String {
        if (yesterday == null || !yesterday.hasEvidence || yesterday.hasScreenHeadline != today.hasScreenHeadline) return "—"
        return UsageRepository.shortDuration(yesterday.totalMillis)
    }

    private fun headlineSource(day: UsageRepository.DayReport): String = when {
        day.hasScreenHeadline -> "可观测屏幕交互区间 · 与 vivo 健康使用口径不保证相同"
        day.hasEvidence -> "仅前台切换事件 · 屏幕记录可能缺失"
        else -> "本日有效系统事件不足 · 无法核实"
    }

    private fun sourceDescription(day: UsageRepository.DayReport): String {
        val screen = if (day.hasScreenHeadline) UsageRepository.shortDuration(day.deviceMillis) else "—（缺少屏幕事件）"
        val events = if (day.hasEvidence) UsageRepository.shortDuration(day.eventTotalMillis) else "—（事件不足）"
        val aggregate = day.androidDailyMillis?.let(UsageRepository::shortDuration) ?: "—（未提供）"
        return "① 屏幕交互事件：$screen\n" +
            "② 前台应用事件：$events（应用排行与小时图）\n" +
            "③ Android 日汇总：$aggregate（厂商可能返回不同日桶）\n\n" +
            "三个值含义不同，不能选择最大的作为正确结果；vivo 官方‘使用统计’可能使用另外的数据源。"
    }

    private fun updateToday(payload: Payload, binding: TodayBinding) {
        val day = payload.today
        val total = UsageRepository.shortDuration(day.totalMillis)
        if (binding.total.text.toString() != total) binding.total.text = total
        val date = headlineSource(day)
        if (binding.date.text.toString() != date) binding.date.text = date
        val currentApp = day.activeApp?.let(repo::appName) ?: "当前没有可识别的前台应用"
        val current = "当前应用  ·  $currentApp"
        if (binding.active.text.toString() != current) binding.active.text = current
        val cap = prefs.getInt("daily_limit_minutes", 0)
        if (cap > 0) {
            val limit = cap * 60_000L
            binding.goalBar?.progress = ((day.totalMillis.toDouble() / limit * 1000).toInt()).coerceIn(0, 1000)
            binding.goalCaption?.text = "今日目标 ${cap} 分钟 · 已完成 ${((day.totalMillis * 100) / limit).coerceAtMost(999)}%"
        }
        binding.heroRing.update(if (cap > 0) day.totalMillis.toFloat() / (cap * 60_000f) else 0f)
        binding.yesterday.text = yesterdayDisplay(day, payload.yesterday)
        binding.average.text = reliableAverage(payload.days)?.let(UsageRepository::shortDuration) ?: "—"
        val diagnostic = sourceDescription(day)
        if (binding.sourceDetails.text.toString() != diagnostic) binding.sourceDetails.text = diagnostic
        binding.hourly.update(day.hourlyMillis)
        binding.chartHint.visibility = if (day.hourlyMillis.any { it > 0L }) View.GONE else View.VISIBLE
        val sorted = day.appMillis.entries.sortedByDescending { it.value }.take(15)
        updateRankings(binding.appCard, sorted, binding.rows, binding.order)
        binding.order = sorted.map { it.key }
    }

    // Reuse app rows when their order is unchanged. Only recreate the ranking section
    // when an app moves up/down or enters/exits the top 15.
    private fun updateRankings(
        card: LinearLayout,
        sorted: List<Map.Entry<String, Long>>,
        rows: MutableMap<String, AppBinding>,
        oldOrder: List<String>
    ) {
        val newOrder = sorted.map { it.key }
        val peak = sorted.firstOrNull()?.value ?: 0L
        val limitRowsChanged = sorted.any { entry ->
            (prefs.getInt("limit_${entry.key}", 0) > 0) != (rows[entry.key]?.limit != null)
        }
        if (oldOrder != newOrder || rows.size != sorted.size || limitRowsChanged ||
            (sorted.isEmpty() && card.childCount == 1)) {
            if (card.childCount > 1) card.removeViews(1, card.childCount - 1)
            rows.clear()
            if (sorted.isEmpty()) {
                card.addView(label("暂无数据。请先授权使用情况访问权限。", 13f, muted))
            } else {
                sorted.forEachIndexed { index, entry ->
                    rows[entry.key] = addAppRow(card, entry.key, entry.value, peak, index + 1)
                }
            }
        } else {
            sorted.forEach { entry ->
                val row = rows[entry.key] ?: return@forEach
                val value = UsageRepository.duration(entry.value)
                if (row.time.text.toString() != value) row.time.text = value
                row.bar.progress = if (peak <= 0L) 0 else
                    ((entry.value.toDouble() / peak * 1000).toInt()).coerceIn(0, 1000)
                val limit = prefs.getInt("limit_${entry.key}", 0)
                if (limit > 0) {
                    row.limit?.text = "限额 $limit 分钟${if (entry.value >= limit * 60_000L) " · 已达到" else ""}"
                    row.limit?.setTextColor(if (entry.value >= limit * 60_000L) Color.rgb(210, 72, 61) else muted)
                }
            }
        }
    }

    private fun miniStat(caption: String, value: TextView, icon: String = "↗"): View {
        val c = card()
        c.setPadding(dp(15), dp(17), dp(12), dp(16))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label(caption, 11f, muted), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label(icon, 17f, blue))
        c.addView(header)
        value.setPadding(0, dp(5), 0, 0)
        c.addView(value)
        return c
    }

    private fun addAppRow(parent: LinearLayout, pkg: String, time: Long, peak: Long, number: Int): AppBinding {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(13), 0, dp(13))
            setOnClickListener { appLimitDialog(pkg) }
        }
        val img = ImageView(this)
        img.setImageDrawable(repo.appIcon(pkg) ?: getDrawable(R.drawable.ic_app))
        img.background = rounded(Color.rgb(244, 250, 250), 11)
        img.setPadding(dp(2), dp(2), dp(2), dp(2))
        row.addView(img, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(12) })
        val central = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val upper = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        upper.addView(label(repo.appName(pkg), 14f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        val timeText = label(UsageRepository.duration(time), 12f, muted)
        upper.addView(timeText)
        central.addView(upper)
        val bar = progress(time, peak, if (number == 1) blue else Color.rgb(84, 193, 190))
        central.addView(bar, LinearLayout.LayoutParams(-1, dp(5)).apply {
            topMargin = dp(10)
        })
        val limit = prefs.getInt("limit_$pkg", 0)
        var limitText: TextView? = null
        if (limit > 0) {
            limitText = label("限额 $limit 分钟${if (time >= limit * 60_000L) " · 已达到" else ""}",
                11f, if (time >= limit * 60_000L) Color.rgb(210, 72, 61) else muted).apply {
                setPadding(0, dp(6), 0, 0)
            }
            central.addView(limitText)
        }
        row.addView(central, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label("›", 22f, muted).apply { setPadding(dp(8), 0, 0, 0) })
        parent.addView(row)
        if (number < 15) parent.addView(View(this).apply { setBackgroundColor(line) },
            LinearLayout.LayoutParams(-1, dp(1)))
        return AppBinding(timeText, bar, limitText)
    }

    private fun showTrends(payload: Payload) {
        val column = newPage()
        if (!repo.hasUsagePermission()) {
            permissionCard(column)
            return
        }
        val intro = card().apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(224, 245, 246), Color.rgb(242, 249, 251))).apply {
                cornerRadius = dp(24).toFloat()
            }
            addView(label("YOUR RHYTHM  /  时间有迹", 10f, deepBlue, true))
            addView(label("慢慢看见自己的节奏", 20f, ink, true).apply { setPadding(0, dp(8), 0, 0) })
            addView(label("过去的每一天，都值得被温柔记录。", 12f, muted).apply { setPadding(0, dp(7), 0, 0) })
        }
        column.addView(intro)
        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(16), 0, dp(2)) }
        listOf(7, 30).forEach { amount ->
            val item = TextView(this).apply {
                text = "近${amount}天"
                gravity = Gravity.CENTER
                textSize = 14f
                setTextColor(if (range == amount) white else muted)
                background = rounded(if (range == amount) blue else Color.rgb(236, 243, 244), 20)
                setOnClickListener {
                    if (range != amount) {
                        range = amount
                        previousScroll = 0
                        refresh()
                    }
                }
            }
            selector.addView(item, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                leftMargin = dp(4); rightMargin = dp(4)
            })
        }
        column.addView(selector, pageWidth())
        val days = payload.days
        val average = reliableAverage(days)
        val trendCard = card()
        trendCard.addView(label("近${range}日平均 · 同口径可观测时长", 13f, muted))
        trendCard.addView(label(average?.let(UsageRepository::shortDuration) ?: "—", 39f, ink, true))
        trendCard.addView(label("${if (average == null) "历史记录不足，暂不计算日均 · " else ""}" +
            "已取得 ${days.count { it.hasEvidence }}/${days.size} 天数据， ≈ 表示系统日汇总", 12f, muted))
        trendCard.addView(DaysChart(this, days.map { it.totalMillis }.toLongArray(), blue),
            LinearLayout.LayoutParams(-1, dp(210)).apply { topMargin = dp(15) })
        column.addView(trendCard, pageWidth().apply { topMargin = dp(14) })
        val rows = card()
        rows.addView(sectionTitle("每日记录", "有数据才计入平均；缺失日期显示未知而非0分钟", "▦"))
        days.asReversed().forEach { day ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(12), 0, dp(12))
            }
            row.addView(label(repo.dateText(day.start), 13f, ink), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(if (!day.hasEvidence) "— 无数据" else
                (if (day.hasEvidence) UsageRepository.duration(day.totalMillis) else "—"), 13f, blue, true))
            rows.addView(row)
            rows.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        column.addView(rows, pageWidth().apply { topMargin = dp(14) })
        column.addView(footnote("主要统计应用前台使用，并非独立的屏幕通电时长。" +
            "事件历史缺失时转为系统日汇总估算；因厂商统计策略和聚合延迟，可能与系统健康使用页面不同。"))
        column.post { (column.parent as? ScrollView)?.scrollTo(0, previousScroll) }
    }

    private fun showSettings() {
        val column = newPage()
        if (!repo.hasUsagePermission()) permissionCard(column)
        val monitor = card()
        column.addView(label("MONITORING  /  监控偏好", 10f, deepBlue, true).apply { setPadding(dp(4), dp(8), 0, dp(12)) })
        monitor.addView(sectionTitle("实时监控", "透明运行 · 状态由你掌控", "◉"))
        addSettingsRow(monitor, "系统使用记录访问", if (repo.hasUsagePermission()) "已授权" else "尚未授权", "查看") {
            openUsageSettings()
        }
        addSettingsRow(monitor, "状态栏实时监控", if (prefs.getBoolean("monitor_enabled", false)) "已启用 · 约30秒更新" else "未启用",
            if (prefs.getBoolean("monitor_enabled", false)) "关闭" else "开启") {
            if (prefs.getBoolean("monitor_enabled", false)) {
                MonitorService.stop(this)
                toast("已停止监控")
            } else if (!repo.hasUsagePermission()) {
                openUsageSettings()
            } else {
                askNotificationPermission()
                try { MonitorService.start(this); toast("监控已开启") }
                catch (_: Exception) { toast("系统限制启动后台服务，请检查权限") }
            }
            refresh()
        }
        addSettingsRow(monitor, "浮动计时气泡", if (prefs.getBoolean("overlay_enabled", false)) "已开启" else "未开启",
            if (prefs.getBoolean("overlay_enabled", false)) "关闭" else "开启") {
            if (prefs.getBoolean("overlay_enabled", false)) {
                prefs.edit().putBoolean("overlay_enabled", false).apply()
                refresh()
            } else if (!Settings.canDrawOverlays(this)) {
                AlertDialog.Builder(this)
                    .setTitle("允许显示在其他应用上层")
                    .setMessage("开启后可在屏幕侧边显示一个可拖动的累计使用时间气泡。此权限不读取屏幕内容。")
                    .setPositiveButton("去授权") { _, _ ->
                        pendingOverlayAuthorization = true
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")))
                    }.setNegativeButton("取消", null).show()
            } else {
                prefs.edit().putBoolean("overlay_enabled", true).apply()
                if (!prefs.getBoolean("monitor_enabled", false) && repo.hasUsagePermission()) {
                    try { MonitorService.start(this) } catch (_: Exception) {}
                }
                refresh()
            }
        }
        column.addView(monitor, pageWidth())

        val goals = card()
        goals.addView(sectionTitle("目标与提醒", "温和提醒，不强制锁定其他应用", "◷"))
        val daily = prefs.getInt("daily_limit_minutes", 0)
        addSettingsRow(goals, "每日总使用目标", if (daily > 0) "$daily 分钟" else "未设置", "编辑") {
            minutesDialog("每日总使用目标", "达到目标时发出一次提醒", "daily_limit_minutes", daily)
        }
        val breakTime = prefs.getInt("break_minutes", 0)
        addSettingsRow(goals, "连续使用提醒", if (breakTime > 0) "$breakTime 分钟" else "未设置", "编辑") {
            minutesDialog("连续使用提醒", "同一应用持续使用达到设定时间时提醒", "break_minutes", breakTime)
        }
        addSettingsRow(goals, "单个应用限额", "进入“今日”页面，点击任意应用设置", "查看") {
            tab = 0; previousScroll = 0; refresh()
        }
        column.addView(goals, pageWidth().apply { topMargin = dp(14) })

        val data = card()
        data.addView(sectionTitle("数据与隐私", "本机处理 · 无账户 · 无云端上传", "◇"))
        addSettingsRow(data, "导出近7天使用数据", "CSV 格式，可使用 Excel 打开", "导出") {
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, "屏幕使用记录_${SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())}.csv")
            }
            startActivityForResult(intent, 62)
        }
        addSettingsRow(data, "系统统计说明", "权限、计算方法与误差来源", "查看") { showInfo() }
        column.addView(data, pageWidth().apply { topMargin = dp(14) })
        column.addView(footnote("屏幕脉搏 1.1.0 · Android 8.0 及以上\n" +
            "本应用只能提醒，不能直接替系统强制限制其他应用。后台服务可能被系统省电策略终止。"))
    }

    private fun addSettingsRow(parent: LinearLayout, name: String, description: String, buttonText: String, callback: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.setPadding(0, dp(16), 0, dp(16))
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label(name, 14f, ink, true))
        details.addView(label(description, 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        val action = label(buttonText, 13f, blue, true).apply {
            setPadding(dp(10), dp(10), dp(2), dp(10))
        }
        row.addView(action)
        row.setOnClickListener { callback() }
        parent.addView(row)
        parent.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
    }

    private fun showInfo() {
        AlertDialog.Builder(this)
            .setTitle("统计方法与隐私")
            .setMessage("通过 Android 的“使用情况访问权限”读取前台应用切换、屏幕交互及锁屏事件。" +
                "按事件重建使用区间，计算每个应用的前台时间，主时长与排行使用相同口径；历史事件缺失时使用系统按日汇总值并标注估算。" +
                "\n\n不同厂商的事件记录、系统自带屏幕使用时长口径和省电机制可能不同，因此数字不保证完全一致。" +
                "\n\n应用不使用网络权限，不读取屏幕图像、QQ聊天内容或其他应用中的文字。" +
                "没有额外的云端数据库。关闭监控不影响系统已保留的统计。")
            .setPositiveButton("知道了", null).show()
    }

    private fun permissionCard(column: LinearLayout) {
        val p = card()
        p.background = rounded(Color.rgb(255, 248, 231), 20)
        p.addView(label("需要授权读取使用统计", 18f, ink, true))
        p.addView(label("Android 默认禁止普通应用读取其他应用的使用记录。点击下方按钮，" +
            "在系统设置中找到“屏幕脉搏”，允许“使用情况访问”。", 13f, muted).apply {
            setPadding(0, dp(10), 0, dp(14))
        })
        p.addView(primaryButton("打开使用情况访问设置") { openUsageSettings() })
        column.addView(p, pageWidth())
    }

    private fun appLimitDialog(pkg: String) {
        val current = prefs.getInt("limit_$pkg", 0)
        minutesDialog("${repo.appName(pkg)} 的每日限额", "达到此应用的时长后通知一次", "limit_$pkg", current)
    }

    private fun minutesDialog(heading: String, hint: String, prefName: String, current: Int) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setText(if (current > 0) current.toString() else "")
            this.hint = "例如：60（分钟）"
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(heading)
            .setMessage(hint + "。输入1–1440分钟；选择“清除”可关闭此提醒。")
            .setView(input)
            .setNegativeButton("取消", null)
            .setNeutralButton("清除") { _, _ ->
                prefs.edit().remove(prefName).apply()
                refresh()
            }
            .setPositiveButton("保存", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = input.text.toString().toIntOrNull()
                if (n == null || n !in 1..1440) {
                    input.error = "请输入1至1440之间的整数"
                } else {
                    prefs.edit().putInt(prefName, n).apply()
                    dialog.dismiss()
                    refresh()
                }
            }
        }
        dialog.show()
    }

    private fun openUsageSettings() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 63)
        }
    }

    @Deprecated("Used solely for the system's ACTION_CREATE_DOCUMENT result on Android 8+.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 62 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        toast("正在导出…")
        executor.execute {
            try {
                val csv = StringBuilder("\uFEFF日期,应用,包名,使用分钟,使用秒数\r\n")
                for (offset in 6 downTo 0) {
                    val day = repo.getDay(offset)
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(day.start))
                    day.appMillis.entries.sortedByDescending { it.value }.forEach { (pkg, ms) ->
                        fun q(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
                        csv.append("$date,${q(repo.appName(pkg))},${q(pkg)},${ms / 60_000},${ms / 1000}\r\n")
                    }
                }
                contentResolver.openOutputStream(uri)?.use { it.write(csv.toString().toByteArray(Charsets.UTF_8)) }
                    ?: error("无法写入所选文件")
                ui.post { toast("CSV 导出完成") }
            } catch (e: Exception) {
                ui.post { toast("导出失败：${e.localizedMessage}") }
            }
        }
    }

    // ----- Presentation helpers -----
    private fun newPage(): LinearLayout {
        todayBinding = null
        body.removeAllViews()
        val scroller = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(19), dp(4), dp(19), dp(38))
        }
        scroller.addView(column, ViewGroup.LayoutParams(-1, -2))
        body.addView(scroller, FrameLayout.LayoutParams(-1, -1))
        return column
    }
    private fun pageWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(19), dp(20), dp(19), dp(20))
        background = rounded(white, 24)
        elevation = dp(2).toFloat()
    }
    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        includeFontPadding = false
        setLineSpacing(dp(2).toFloat(), 1f)
    }
    private fun sectionTitle(name: String, description: String, icon: String = "✧"): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label(icon, 21f, blue, true).apply { setPadding(0, 0, dp(9), 0) })
        row.addView(label(name, 17f, ink, true))
        addView(row)
        addView(label(description, 11f, muted).apply { setPadding(0, dp(5), 0, dp(16)) })
    }
    private fun divider(container: LinearLayout, margin: Int) {
        container.addView(View(this).apply { setBackgroundColor(Color.rgb(212, 224, 247)) },
            LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(margin); bottomMargin = dp(margin)
            })
    }
    private fun primaryButton(s: String, onClick: () -> Unit): View = TextView(this).apply {
        text = s
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(white)
        gravity = Gravity.CENTER
        setPadding(dp(15), dp(14), dp(15), dp(14))
        background = rounded(blue, 12)
        setOnClickListener { onClick() }
    }
    private fun footnote(s: String): View = label(s, 11f, muted).apply {
        setPadding(dp(7), dp(18), dp(7), dp(5))
    }
    private fun progress(current: Long, target: Long, tint: Int): ProgressBar =
        ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progress = if (target <= 0) 0 else ((current.toDouble() / target * 1000).toInt()).coerceIn(0, 1000)
            progressTintList = ColorStateList.valueOf(tint)
            progressBackgroundTintList = ColorStateList.valueOf(line)
        }
    private fun dp(i: Int): Int = (resources.displayMetrics.density * i + 0.5f).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Minimal radial target mark. Animated system redraws do not recreate the page. */
class UsageRingView(context: Context, fraction: Float) : View(context) {
    private val density = resources.displayMetrics.density
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f * density
        strokeCap = Paint.Cap.ROUND
    }
    private val captionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(22, 115, 139)
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = 14f * resources.displayMetrics.scaledDensity
    }
    private var progressFraction = fraction.coerceIn(0f, 1f)
    fun update(value: Float) {
        val next = value.coerceIn(0f, 1f)
        if (kotlin.math.abs(next - progressFraction) > 0.001f) {
            progressFraction = next
            invalidate()
        }
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val x = width / 2f
        val y = height / 2f
        val radius = minOf(width, height) / 2f - ringPaint.strokeWidth - 4 * density
        val bounds = android.graphics.RectF(x - radius, y - radius, x + radius, y + radius)
        ringPaint.color = Color.rgb(202, 226, 230)
        canvas.drawArc(bounds, 0f, 360f, false, ringPaint)
        ringPaint.color = Color.rgb(18, 151, 165)
        canvas.drawArc(bounds, -90f, 360f * progressFraction, false, ringPaint)
        val caption = if (progressFraction == 0f) "◷" else "${(progressFraction * 100).toInt()}%"
        canvas.drawText(caption, x, y - (captionPaint.ascent() + captionPaint.descent()) / 2, captionPaint)
    }
}

/** Compact hour-level bar chart, no third-party UI/chart dependencies. */
class HourChart(context: Context, private val millis: LongArray, private val tint: Int) : View(context) {
    fun update(values: LongArray) {
        if (millis.contentEquals(values)) return
        java.util.Arrays.fill(millis, 0L)
        values.copyInto(millis, endIndex = minOf(values.size, millis.size))
        invalidate()
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 145, 160); textSize = sp(10f) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val l = dp(3f)
        val r = width - dp(3f)
        val top = dp(12f)
        val baseline = height - dp(27f)
        val area = baseline - top
        val maxValue = max(3_600_000L, millis.maxOrNull() ?: 0L)
        paint.color = Color.rgb(230, 238, 239)
        paint.strokeWidth = dp(1f)
        for (i in 0..3) {
            val yy = top + area * i / 3f
            canvas.drawLine(l, yy, r, yy, paint)
        }
        val segment = (r - l) / 24f
        millis.forEachIndexed { i, v ->
            val h = area * (v.toFloat() / maxValue)
            val x = l + segment * (i + .18f)
            paint.color = if (i == java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) Color.rgb(8, 116, 149) else tint
            canvas.drawRoundRect(x, baseline - h, x + segment * .64f, baseline, dp(3f), dp(3f), paint)
        }
        for (hour in listOf(0, 6, 12, 18, 23)) {
            val s = "%02d".format(Locale.US, hour)
            val x = (l + segment * (hour + .5f) - label.measureText(s) / 2).coerceAtLeast(0f)
            canvas.drawText(s, x, height - dp(5f), label)
        }
    }
    private fun dp(i: Float) = i * resources.displayMetrics.density
    private fun sp(i: Float) = i * resources.displayMetrics.scaledDensity
}

class DaysChart(context: Context, private val times: LongArray, private val tint: Int) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(130, 145, 160); textSize = sp(10f) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (times.isEmpty()) return
        val left = dp(8f)
        val right = width - dp(8f)
        val top = dp(11f)
        val bottom = height - dp(28f)
        val available = bottom - top
        val maxValue = max(times.maxOrNull() ?: 0L, 60_000L)
        p.color = Color.rgb(231, 239, 240)
        for (i in 0..3) {
            val yy = top + available * i / 3f
            canvas.drawLine(left, yy, right, yy, p)
        }
        val widthEach = (right - left) / times.size
        times.forEachIndexed { index, ms ->
            val x = left + widthEach * (index + .16f)
            val barHeight = available * (ms.toFloat() / maxValue)
            p.color = if (index == times.lastIndex) Color.rgb(14, 126, 155) else tint
            canvas.drawRoundRect(x, bottom - barHeight, x + widthEach * .68f,
                bottom, dp(if (times.size > 10) 2f else 4f), dp(4f), p)
        }
        val every = when {
            times.size <= 7 -> 1
            times.size <= 14 -> 3
            else -> 6
        }
        times.indices.filter { it % every == 0 || it == times.lastIndex }.forEach { index ->
            val s = "${index + 1}"
            val x = left + widthEach * (index + .5f) - label.measureText(s) / 2
            canvas.drawText(s, x, height - dp(6f), label)
        }
    }
    private fun dp(i: Float) = i * resources.displayMetrics.density
    private fun sp(i: Float) = i * resources.displayMetrics.scaledDensity
}
